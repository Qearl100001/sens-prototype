import type { ComponentType } from "react";
import { COLORFUL_ICON_REGISTRY } from "./colorful-icons";
import type { FilledIconName } from "./filled-icon-names";
import type { IconAssetMeta, IconName, IconVariant, RegistryIconRenderProps } from "./types";
export interface IconRegistryEntry extends IconAssetMeta {
    Component: ComponentType<RegistryIconRenderProps>;
}
/** Figma 线性图标优先覆盖同名历史手写资产；未迁移的历史 Sens 图标继续保留。 */
export declare const ICON_REGISTRY: Record<IconName, IconRegistryEntry>;
export declare const ICON_NAMES: IconName[];
export declare const FILLED_ICON_REGISTRY: Record<FilledIconName, IconRegistryEntry>;
export { FILLED_ICON_NAMES } from "./filled-icon-names";
export { COLORFUL_ICON_NAMES } from "./colorful-icon-names";
export { COLORFUL_ICON_REGISTRY };
export declare function getIconRegistryEntry(name: IconName, variant?: IconVariant): IconRegistryEntry;
export declare function isIconName(value: string): value is IconName;
