import type { IconRegistryEntry } from "./registry";
import { type FilledIconName } from "./filled-icon-names";
export declare const FIGMA_FILLED_ICON_REGISTRY: Record<FilledIconName, IconRegistryEntry>;
