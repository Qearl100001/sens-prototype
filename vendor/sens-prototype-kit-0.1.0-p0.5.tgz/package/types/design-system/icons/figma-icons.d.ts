import type { IconRegistryEntry } from "./registry";
import { type FigmaIconName } from "./figma-icon-names";
export declare const FIGMA_ICON_REGISTRY: Record<FigmaIconName, IconRegistryEntry>;
