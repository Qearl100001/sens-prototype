import type { IconRegistryEntry } from "./registry";
import { COLORFUL_ICON_NAMES, type ColorfulIconName } from "./colorful-icon-names";
export declare const COLORFUL_ICON_REGISTRY: Record<ColorfulIconName, IconRegistryEntry>;
export { COLORFUL_ICON_NAMES };
export type { ColorfulIconName };
