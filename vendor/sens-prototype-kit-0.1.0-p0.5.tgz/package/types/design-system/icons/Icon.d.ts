import type { IconColorRole, IconSizeTokenName, SensIconProps } from "./types";
/** InputNumber stepper 组件内部特殊尺寸，非通用 icon size token */
export declare const STEPPER_ICON_SIZE = 10;
export declare function getIconSizeToken(name: IconSizeTokenName): number;
export declare function resolveIconColor(role: IconColorRole): string;
/** 统一图标渲染入口；尺寸与颜色由使用场景传入，registry 不绑定默认值。 */
export declare function SensIcon({ name, variant, size, sizeToken, colorRole, color, className, style, }: SensIconProps): import("react").JSX.Element;
