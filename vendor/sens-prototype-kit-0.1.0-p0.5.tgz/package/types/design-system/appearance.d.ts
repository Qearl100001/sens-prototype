import { type CSSProperties, type ReactNode } from "react";
import { type FunctionalColorSet, type FunctionalSkin } from "./functional-skin";
import { type NavigationTheme } from "./navigation-color";
/**
 * 预览 / 应用层换肤入口。
 * FunctionalSkin 与 NavigationTheme 默认同步设置保留给快捷入口；规则上两套始终可独立组合。
 */
export type SensAppearanceValue = {
    functionalSkin: FunctionalSkin;
    navigationTheme: NavigationTheme;
    /** 默认同步设置两套主题；需要验证品牌色/功能色差异时使用独立 setter。 */
    setAppearance: (skin: FunctionalSkin) => void;
    setFunctionalSkin: (skin: FunctionalSkin) => void;
    setNavigationTheme: (theme: NavigationTheme) => void;
};
export type SensAppearanceProviderProps = {
    functionalSkin: FunctionalSkin;
    navigationTheme: NavigationTheme;
    onFunctionalSkinChange: (skin: FunctionalSkin) => void;
    onNavigationThemeChange: (theme: NavigationTheme) => void;
    children: ReactNode;
};
/** 注入当前肤色 CSS 变量，供组件消费。 */
export declare function appearanceCssVars(functionalSkin: FunctionalSkin, navigationTheme: NavigationTheme): CSSProperties;
export declare function SensAppearanceProvider({ functionalSkin, navigationTheme, onFunctionalSkinChange, onNavigationThemeChange, children, }: SensAppearanceProviderProps): import("react").JSX.Element;
export declare function useSensAppearance(): SensAppearanceValue;
/** 预览壳外或测试：无 Provider 时回落绿基线 */
export declare function useFunctionalSkin(): FunctionalSkin;
export declare function useNavigationTheme(): NavigationTheme;
export declare function useFunctionalColorSet(): FunctionalColorSet;
