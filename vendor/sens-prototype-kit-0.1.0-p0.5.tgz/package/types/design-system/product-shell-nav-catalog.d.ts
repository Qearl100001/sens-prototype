import { type ProductShellDomainNav, type ProductShellDomainTopDropdownConfig } from "./product-shell-domain-nav";
/** 概览顶导已去掉；可视化内「概览」叶子、广告/资源管理内同名叶子仍保留。 */
/** Figma 可视化侧导 */
export declare const VISUALIZATION_DOMAIN_NAV: ProductShellDomainNav;
/** 分析专属：虚拟二级 + 面性落地项 */
export declare const ANALYSIS_DOMAIN_NAV: ProductShellDomainNav;
/** Figma A/B 测试 */
export declare const AB_TEST_DOMAIN_NAV: ProductShellDomainNav;
/** Figma 智能运营 `3709:3989` */
export declare const SMART_OPS_DOMAIN_NAV: ProductShellDomainNav;
/** Figma 内容管理 */
export declare const CONTENT_DOMAIN_NAV: ProductShellDomainNav;
/** Figma 营销助手 */
export declare const MARKETING_ASSISTANT_DOMAIN_NAV: ProductShellDomainNav;
/** Figma 广告投放分析（替代渠道追踪） */
export declare const AD_ANALYSIS_DOMAIN_NAV: ProductShellDomainNav;
/** 场景库占位 */
export declare const SCENE_LIBRARY_DOMAIN_NAV: ProductShellDomainNav;
/** Figma 数据融合（独立入口，不与数据加工合并）— 优先 22269 */
export declare const DATA_FUSION_DOMAIN_NAV: ProductShellDomainNav;
/**
 * Figma 数据加工（独立入口）。
 * 含原先在外层的分群 / 标签。
 */
export declare const DATA_PROCESS_DOMAIN_NAV: ProductShellDomainNav;
/** 右上角审批 → 审批中心 */
export declare const APPROVAL_DOMAIN_NAV: ProductShellDomainNav;
/** 右上角资源管理 */
export declare const WORKLOAD_DOMAIN_NAV: ProductShellDomainNav;
/** 右上角平台 → 平台管理（22269 完整版） */
export declare const PLATFORM_DOMAIN_NAV: ProductShellDomainNav;
/** 全部域（侧导切换 + 顶导派生目录） */
export declare const PRODUCT_SHELL_TEMPLATE_DOMAINS: ProductShellDomainNav[];
/** 仅主导航第一层入口（不含右上角 utility 域） */
export declare const PRODUCT_SHELL_PRIMARY_DOMAINS: ProductShellDomainNav[];
export type ProductShellPrimaryNavItem = {
    label: string;
    arrow?: boolean;
};
/** 顶导第二行默认 items（唯一源；组件与样板间共用） */
export declare function getProductShellPrimaryNavItems(): ProductShellPrimaryNavItem[];
/** 顶导下拉默认配置（唯一源；有侧导的域为 flat/grouped 派生结果） */
export declare function getProductShellNavDropdownByLabel(): Record<string, ProductShellDomainTopDropdownConfig>;
/** 各域默认落地页（第一叶子），供顶导非受控初始选中 */
export declare function getProductShellDefaultNavMenuByLabel(): Record<string, string>;
