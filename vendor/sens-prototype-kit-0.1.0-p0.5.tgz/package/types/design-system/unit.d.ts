/** 将 `spacing/0.5x` 等 ASCII 写法归一为 `spacing/0․5x`。 */
export declare function normalizeUnitTokenName(name: string): string;
/** 读取 spacing / size / radius 等 unit token；优先 tokens.resolved.json，缺失时 dev warn + 0 兜底。 */
export declare function getUnitToken(name: string): number;
