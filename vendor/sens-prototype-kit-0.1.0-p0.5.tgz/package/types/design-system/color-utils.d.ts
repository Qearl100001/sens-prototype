export declare function hexToRgba(hex: string, alpha: number): string;
/** 从语义 handle 取色并带透明度（禁止在业务里手写 rgba 字面量） */
export declare function tokenRgba(handle: string, alpha: number): string;
export declare function getColorToken(handle: string): string;
/** 从 Figma 变量路径取色，用于基础色板、定制色等尚未抽成语义 handle 的色值 */
export declare function getColorByPath(path: string): string;
export type ShadowLevel = "D1" | "D2" | "D3" | "D4";
export type ShadowDirection = "down" | "up" | "left" | "right";
export type DrawerShadowDirection = "right";
export type ActiveRingShadowHandle = "component-active-shadow" | "warning-color-active-shadow";
export declare function buildShadow(level: ShadowLevel, direction?: ShadowDirection): string;
/** D1↓：胶囊等选中投影（本次按钮不改引用，供后续 Segmented 等接入） */
export declare function buildShadowD1(): string;
/** D2↓：中低层级容器 / 轻量浮层 */
export declare function buildShadowD2(): string;
/** D3↓：一级/二级（含 dangerSecondary）仅 hover */
export declare function buildShadowD3(): string;
/** D4↓：悬浮按钮全状态恒有 */
export declare function buildShadowD4(): string;
/** 右侧 Drawer 专用侧向投影，来源 Sens.Design 抽屉组件。 */
export declare function buildDrawerShadow(direction?: DrawerShadowDirection): string;
export declare function buildActiveRingShadow(handle: ActiveRingShadowHandle): string;
export declare const SHADOW_NONE: "none";
