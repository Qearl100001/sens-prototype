/** 预览换肤：仅切换功能色，状态色（链接蓝等）不变。 */
export type FunctionalSkin = "green" | "blue" | "limeGreen" | "auroraGreen" | "landscapeBlue" | "orchidPurple" | "wavePurple";
export declare const FUNCTIONAL_SKIN_LABELS: Record<FunctionalSkin, string>;
/** 功能色 01–10；对应 Figma 换肤表下半区 */
export type FunctionalColorSet = {
    primary: string;
    hover: string;
    active: string;
    disable: string;
    disableHover: string;
    activeBackground: string;
    activeHoverBackground: string;
    activeClickBackground: string;
    activeShadow: string;
    lightBackground: string;
};
/** 与 appearanceCssVars 注入的 --sens-skin-* 对齐 */
export type FunctionalCssVar = "--sens-skin-primary" | "--sens-skin-hover" | "--sens-skin-active" | "--sens-skin-disable" | "--sens-skin-disable-hover" | "--sens-skin-active-bg" | "--sens-skin-active-hover-bg" | "--sens-skin-active-click-bg" | "--sens-skin-active-shadow" | "--sens-skin-light-bg";
type FunctionalFallbackHandle = "component-primary" | "component-hover" | "component-active" | "component-disable" | "component-disable-hover" | "component-active-background" | "component-active-hover-background" | "component-active-click-background" | "component-active-shadow" | "component-light-background";
export declare function getFunctionalColors(skin?: FunctionalSkin): FunctionalColorSet;
/**
 * 组件样式取功能色：有 AppearanceProvider 时跟肤，否则回落绿基线 handle。
 * 返回值可直接用于 inline style / CSS 自定义属性。
 */
export declare function functionalCssVar(cssVar: FunctionalCssVar, fallbackHandle: FunctionalFallbackHandle): string;
/** 功能色点击投影环；随 --sens-skin-active-shadow */
export declare function buildFunctionalActiveRingShadow(functional?: FunctionalColorSet): string;
export {};
