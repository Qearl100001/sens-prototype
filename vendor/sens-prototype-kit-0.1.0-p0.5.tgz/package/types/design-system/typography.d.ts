export declare const SENS_FONT_FAMILY = "-apple-system, BlinkMacSystemFont, \"Segoe UI\", \"PingFang SC\", \"Hiragino Sans GB\", \"Microsoft YaHei\", \"Helvetica Neue\", Helvetica, Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\"";
/**
 * 将 Sens 字体栈挂到 html/body/#root，保证非 antd 节点与文档根继承同一来源。
 * 字体主权在 Sens；antd 只通过 theme.token.fontFamily 承接，不定义字体。
 */
export declare function applySensFontFamilyToDocument(doc?: Document): void;
export declare const TYPOGRAPHY_TOKEN_NAMES: readonly ["font-size/s", "font-size/m", "font-size/l", "font-size/xl", "font-size/xxl", "font-size/display", "line-height/s", "line-height/m", "line-height/l", "line-height/xl", "line-height/xxl", "line-height/display", "font-weight/regular", "font-weight/medium", "font-weight/semibold"];
export type TypographyTokenName = (typeof TYPOGRAPHY_TOKEN_NAMES)[number];
/** 读取 typography token；优先 tokens.resolved.json，缺失时 dev warn + 单条兜底。 */
export declare function getTypographyToken(name: TypographyTokenName): number;
