export type NavigationTheme = "green" | "blue" | "wildYellow" | "limeGreen" | "duneGold" | "sunriseRed" | "auroraGreen" | "landscapeBlue" | "orchidPurple" | "wavePurple" | "cloudPink" | "midnightBlack";
export declare const NAVIGATION_THEME_LABELS: Record<NavigationTheme, string>;
type NavigationThemeTokens = {
    top: {
        background: string;
        atmosphere: string;
    };
    side: {
        background: string;
    };
    title: {
        background: string;
    };
    page: {
        background: string;
    };
    accent: {
        solid: string;
        subtle: string;
    };
    /** 品牌态 handle 覆盖；绿肤为空时回落 Color.json */
    handles: Record<string, string>;
};
export declare const DEFAULT_NAVIGATION_THEME: NavigationTheme;
/** 产品壳主题与功能色主题独立。新增导航肤色时必须补齐顶导、侧导、标题栏、页面、accent 与品牌 handles。 */
export declare function getNavigationTheme(theme?: NavigationTheme): NavigationThemeTokens;
/** 顶导航背景渐变，来自 NavigationTheme Token。 */
export declare function getThemeTopBackground(theme?: NavigationTheme): string;
/** 顶导航氛围叠层，独立于基础背景渐变，随产品壳主题变化。 */
export declare function getThemeTopAtmosphere(theme?: NavigationTheme): string;
/** 侧导航背景渐变，来自 NavigationTheme Token。 */
export declare function getThemeSideBackground(theme?: NavigationTheme): string;
/** 标题栏背景（drilldown / 抽屉标题区），来自 NavigationTheme Token。 */
export declare function getThemeTitleBackground(theme?: NavigationTheme): string;
/** 顶导下页面背景，来自 NavigationTheme Token。 */
export declare function getThemePageBackground(theme?: NavigationTheme): string;
type NavigationCssVar = "--sens-nav-title-bg" | "--sens-nav-page-bg";
type NavigationFallbackHandle = "theme-title-background" | "body-background";
/**
 * Appearance 注入的导航 CSS 变量；无 Provider 时回落 Color.json 绿基线 handle。
 * 标题栏 / 页面底换肤须走此入口或 getThemeTitle/PageBackground，禁止裸 getColorToken。
 */
export declare function navigationCssVar(cssVar: NavigationCssVar, fallbackHandle: NavigationFallbackHandle): string;
/** 导航品牌实色 / 浅底（选中强调）；与 Functional Skin 独立。 */
export declare function getNavigationAccent(theme?: NavigationTheme): {
    solid: string;
    subtle: string;
};
/**
 * 读导航语义色：当前主题优先用 navigationTheme.handles 覆盖品牌态；
 * 未覆盖的中性态回落 Color.json handle。
 */
export declare function getNavigationColorToken(handle: string, theme?: NavigationTheme): string;
export {};
