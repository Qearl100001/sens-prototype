import type { CSSProperties } from "react";
/** 三态字色链：default / hover / active */
export interface TextColorChain {
    default: string;
    hover: string;
    active: string;
}
/** 共享语义前缀：链接蓝（状态色 link-color 链） */
export declare const SENS_TEXT_LINK_VAR = "--sens-text-link";
/** 共享语义前缀：警告红（warning-color 三态链） */
export declare const SENS_TEXT_WARNING_VAR = "--sens-text-warning";
/** 链接字色链：直读 design token link-color 三态链（与 variant="link" 视觉同源） */
export declare function getLinkTextChain(): TextColorChain;
/** 警告字色链：直读 design token warning-color 三态链（与 Button danger 链视觉同源） */
export declare function getWarningTextChain(): TextColorChain;
/**
 * 将字色链注入为 CSS 自定义属性。
 * @param prefix 如 `--sens-text-link` → `--sens-text-link` / `-hover` / `-active`
 */
export declare function toTextChainCssVars(prefix: string, chain: TextColorChain): CSSProperties;
/** 菜单项字色别名：共享链 → dropdown-menu scoped 变量（换源不换值） */
export declare function toDropdownMenuLinkColorAliases(): CSSProperties;
export declare function toDropdownMenuDangerColorAliases(): CSSProperties;
