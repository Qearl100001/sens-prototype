import { type ThemeConfig } from "antd";
/** 一级常规实心描边（midnight-dark-04）；仅 SensButton tone=primary */
export declare function getButtonPrimaryBorderColor(): string;
/** Sens 字体栈灌入 antd 承接层；勿依赖 antd seed 默认字体。 */
export declare function buildAntdTheme(mode?: "light" | "dark"): ThemeConfig;
