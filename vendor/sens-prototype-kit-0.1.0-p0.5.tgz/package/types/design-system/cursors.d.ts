/**
 * SensD 鼠标态 registry
 *
 * 实现：系统 CSS `cursor` 关键字（原生观感）。
 * 规则：SensD《鼠标指针》语义（labelZh / description / 分组 / 场景约定）。
 * `illustration`：走查页可选示意 PNG，不参与真实光标。
 *
 * 页签拖拽等「换位」用 `move`（对齐规则「移动」），不要用 grab/grabbing。
 * 注意：`how-cursor-works.md` 是 Cursor AI 工作说明，与本 registry 无关。
 */
export type SensCursorName = "default" | "pointer" | "not-allowed" | "text" | "vertical-text" | "crosshair" | "move" | "no-drop" | "grab" | "grabbing" | "copy" | "n-resize" | "e-resize" | "s-resize" | "w-resize" | "ne-resize" | "nw-resize" | "se-resize" | "sw-resize" | "ns-resize" | "ew-resize" | "nesw-resize" | "nwse-resize" | "col-resize";
export type SensCursorDef = {
    /** CSS 类名，如 `sens-cursor-move` */
    className: string;
    /** CSS 变量名，如 `--sens-cursor-move` */
    cssVar: string;
    /** 系统 `cursor` 关键字（真实生效值） */
    cssValue: string;
    /** 走查页示意图（可选；不参与 cursor） */
    illustration?: string;
    /** Figma / 规则来源 */
    figma: string;
    /** 分组：默认 / 状态 / 选择 / 移动 / 调整尺寸 */
    group: "default" | "state" | "select" | "move" | "resize";
    /** 规则稿中文名 */
    labelZh: string;
    /** 规则稿描述（统一用「标示」） */
    description: string;
    /** 主验（规则优先 8 态） */
    primary?: boolean;
};
export declare const SENS_CURSORS: Record<SensCursorName, SensCursorDef>;
/** 规则优先主验 8 态 */
export declare const SENS_CURSOR_PRIMARY: SensCursorName[];
/** 真实生效的 `cursor` 值（系统关键字） */
export declare function sensCursorValue(name: SensCursorName): string;
/** 页签拖拽等「移动」场景统一入口 */
export declare const SENS_CURSOR_MOVE: SensCursorDef;
