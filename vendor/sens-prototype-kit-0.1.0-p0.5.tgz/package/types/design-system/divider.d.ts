export type DividerTone = "deep" | "outline" | "light" | "weak";
export type DividerColorMode = "transparent" | "solid";
/** 颜色 handle ↔ Divider Foundation token 权威对照；样张与迁移审计用。 */
export interface DividerHandleMapping {
    tokenName: string;
    tone: DividerTone;
    mode: DividerColorMode;
    transparentHandle: string;
    solidHandle: string;
    alpha: number;
    figmaName: string;
    recommendedApi: string;
    legacyTransparentApi: string;
}
export declare const DIVIDER_HANDLE_MAPPINGS: DividerHandleMapping[];
/** 从旧颜色 handle 解析 divider tone/mode；未知 handle 返回 null。 */
export declare function resolveDividerFromColorHandle(handle: string): {
    tone: DividerTone;
    mode: DividerColorMode;
} | null;
export declare function getDividerTokenName(tone: DividerTone, mode?: DividerColorMode): string;
/** 读取分割线色；优先 tokens.resolved.json，缺失时 dev warn + outline 单色兜底。 */
export declare function getDividerColor(tone: DividerTone, mode?: DividerColorMode): string;
/** 读取 hairline 线宽；优先 tokens.resolved.json，缺失时 dev warn + 1px 兜底。 */
export declare function getDividerHairlineWidth(): number;
export declare function getDividerBorder(tone: DividerTone, mode?: DividerColorMode): string;
