export interface SelectDropdownActionBarProps {
    selectedCount: number;
    selectAllChecked: boolean;
    selectAllIndeterminate: boolean;
    selectAllDisabled?: boolean;
    onSelectAllChange: (checked: boolean) => void;
    onDiscard: () => void;
    onComplete: () => void;
}
/** 多选浮层底部操作条：全选 + 放弃 + 完成 (N)。Figma `17691:63201`。 */
export declare function SelectDropdownActionBar({ selectedCount, selectAllChecked, selectAllIndeterminate, selectAllDisabled, onSelectAllChange, onDiscard, onComplete, }: SelectDropdownActionBarProps): import("react").JSX.Element;
