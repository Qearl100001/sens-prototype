import { type CSSProperties, type ReactNode } from "react";
import { type MessageType } from "./SensMessage";
export type SensMessageDuration = number | null;
export type SensMessageOpenOptions = {
    key?: string;
    type?: MessageType;
    content: ReactNode;
    link?: ReactNode;
    closable?: boolean;
    duration?: SensMessageDuration;
    onClose?: () => void;
};
export type SensMessageShortcutOptions = Omit<SensMessageOpenOptions, "content" | "type">;
export type SensMessageClose = () => void;
export type SensMessageApi = {
    open: (options: SensMessageOpenOptions) => SensMessageClose;
    default: (content: ReactNode, options?: SensMessageShortcutOptions) => SensMessageClose;
    success: (content: ReactNode, options?: SensMessageShortcutOptions) => SensMessageClose;
    info: (content: ReactNode, options?: SensMessageShortcutOptions) => SensMessageClose;
    warning: (content: ReactNode, options?: SensMessageShortcutOptions) => SensMessageClose;
    loading: (content: ReactNode, options?: SensMessageShortcutOptions) => SensMessageClose;
    destroy: (key?: string) => void;
};
export type SensMessageProviderProps = {
    children?: ReactNode;
    hostStyle?: CSSProperties;
    /** 页面顶部偏移；默认使用 spacing/vertical/6x。 */
    top?: number;
};
export declare function SensMessageProvider({ children, hostStyle, top, }: SensMessageProviderProps): import("react").JSX.Element;
export declare function useSensMessage(): SensMessageApi;
