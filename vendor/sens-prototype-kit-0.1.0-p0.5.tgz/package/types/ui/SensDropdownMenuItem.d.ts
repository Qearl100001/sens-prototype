import type { CSSProperties, KeyboardEvent, MouseEvent, ReactNode } from "react";
import "./dropdown-menu.css";
export type SensDropdownMenuItemVariant = "default" | "link" | "danger";
export interface SensDropdownMenuItemConfig {
    key: string;
    label: ReactNode;
    variant?: SensDropdownMenuItemVariant;
    disabled?: boolean;
    loading?: boolean;
    onClick?: () => void;
}
export type SensDropdownMenuItemPreviewState = "default" | "hover" | "active" | "disabled" | "disabledHover" | "loading" | "loadingHover";
export interface SensDropdownMenuItemProps {
    variant?: SensDropdownMenuItemVariant;
    disabled?: boolean;
    loading?: boolean;
    onClick?: (event: MouseEvent<HTMLDivElement> | KeyboardEvent<HTMLDivElement>) => void;
    children: ReactNode;
    className?: string;
    style?: CSSProperties;
}
export declare function SensDropdownMenuItem({ variant, disabled, loading, onClick, children, className, style, }: SensDropdownMenuItemProps): import("react").JSX.Element;
