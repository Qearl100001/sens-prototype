import type { CSSProperties } from "react";
export declare function useSearchTokens(): {
    previewVars: CSSProperties;
};
export declare function useSearchRootStyle(extra?: CSSProperties): CSSProperties;
