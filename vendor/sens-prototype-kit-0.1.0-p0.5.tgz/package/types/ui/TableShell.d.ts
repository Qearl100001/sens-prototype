import { type ReactNode } from "react";
import type { TableProps } from "antd";
import type { NonPageEmptyIllustrationKey } from "./EmptyStateIllustrations";
import { type SensButtonVariant } from "./SensButton";
import "./table.css";
export interface TableActionItem {
    key: string;
    label: ReactNode;
    onClick?: () => void;
    disabled?: boolean;
}
export type TableInfoActionTone = Extract<SensButtonVariant, "secondary" | "tertiary" | "dangerSecondary" | "dangerSecondaryWeak" | "dangerTertiary" | "dangerTertiaryWeak">;
export interface TableInfoActionItem extends TableActionItem {
    /** 批量操作区使用小按钮；默认 secondary；删除等其他风险用 dangerSecondaryWeak；取消选择等弱操作用 tertiary */
    tone?: TableInfoActionTone;
}
/** 信息栏右侧设置列目前可追加的动作：仅小号链接按钮。 */
export interface TableInfoLinkAction extends TableActionItem {
}
export interface TableInfoBarProps {
    /** 默认计数，展示为「共 N 条」 */
    total?: number;
    /** 筛选结果计数，传入后展示为「已找到 N 条」 */
    foundTotal?: number;
    /** 当前页选中数量，传入且大于 0 时追加「当页选中 N 条」 */
    selectedCount?: number;
    /** 信息区批量操作：小号二级 / 二级弱警告 / 三级按钮 */
    actions?: TableInfoActionItem[];
    /** 信息区右侧设置列目前的链接动作；仅渲染为小号链接按钮。 */
    linkActions?: TableInfoLinkAction[];
    /** 信息区最右侧操作入口，例如列设置 icon */
    extra?: ReactNode;
    /** 自定义信息区内容；传入后替代默认计数文案 */
    children?: ReactNode;
}
export interface TableShellProps<T extends object> extends TableProps<T> {
    /** 信息区计数，默认「共 N 条」；未传时取 dataSource.length */
    total?: number;
    /** 筛选结果计数，传入后展示为「已找到 N 条」 */
    foundTotal?: number;
    /** 当前页选中数量，传入且大于 0 时追加「当页选中 N 条」 */
    selectedCount?: number;
    /** 信息区批量操作：小号二级 / 二级弱警告 / 三级按钮 */
    infoActions?: TableInfoActionItem[];
    /** 信息区右侧设置列目前的链接动作；仅渲染为小号链接按钮。 */
    infoLinkActions?: TableInfoLinkAction[];
    /** 信息区最右侧操作入口，例如列设置 icon */
    infoExtra?: ReactNode;
    /** 自定义信息区内容 */
    infoContent?: ReactNode;
    /** 表格框内底部区域；复合表格可放分页器，不改变基础表格 pagination=false 的约定 */
    footerBar?: ReactNode;
    /** 是否展示信息区；高度来自 size/component-height/xl */
    showInfoBar?: boolean;
    /** 空状态插图类型 */
    emptyState?: NonPageEmptyIllustrationKey;
    /** 覆盖空态说明；不传则走 SensEmptyState 默认标题 + 说明（含添加 / 刷新链接） */
    emptyDescription?: ReactNode;
    /** 空状态额外操作；默认空态用说明内嵌链接，不必再塞三级按钮 */
    emptyAction?: ReactNode;
    /** 嵌套在卡片内时去掉外壳描边，避免双层边框 */
    borderless?: boolean;
    /**
     * 页面内容区滚动时，让表头跟随到内容区顶部；只用于没有表体内部纵向滚动的长表格页面。
     * 表头离开表格底部后必须随表格离场，不能成为全局固定导航。
     */
    stickyHeader?: "page";
}
export declare function TableInfoBar({ total, foundTotal, selectedCount, actions, linkActions, extra, children, }: TableInfoBarProps): import("react").JSX.Element;
/** 信息区右侧列设置：icon-only 小号弱化链接，不展示「设置」文案（table.md） */
export declare function TableInfoColumnSettingButton(): import("react").JSX.Element;
export interface TableInfoRefreshableSummaryProps {
    /** 计数文案前缀默认「共」；筛选结果传「已找到」 */
    prefix?: "共" | "已找到";
    total: number;
    /** 展示为 yyyy-mm-dd hh:mm:ss */
    updatedAt: string;
    onRefresh?: () => void;
}
/**
 * 数据更新可刷新：文案后紧跟 reload 弱化链接按钮；与列设置（infoExtra）分离。
 */
export declare function TableInfoRefreshableSummary({ prefix, total, updatedAt, onRefresh, }: TableInfoRefreshableSummaryProps): import("react").JSX.Element;
/**
 * 基础表格外壳：信息区 + 表体（见 components/base/table.md）
 * 所有视觉值都读取 SensD token；antd Table 只承担表格 DOM 与交互适配。
 */
export declare function TableShell<T extends object>({ total, foundTotal, selectedCount, infoActions, infoLinkActions, infoExtra, infoContent, footerBar, showInfoBar, emptyState, emptyDescription, emptyAction, borderless, stickyHeader, columns, dataSource, className, locale, pagination, rowSelection, onChange, ...rest }: TableShellProps<T>): import("react").JSX.Element;
export interface LinkButtonProps {
    children: ReactNode;
    onClick?: () => void;
    disabled?: boolean;
    /** weak 用于可下钻主属性；link 用于操作列。两者 hover 均进入链接蓝。 */
    tone?: "weak" | "link";
}
/** 链接按钮：弱链接用于可下钻主属性；常规链接用于操作列。 */
export declare function LinkButton({ children, onClick, disabled, tone }: LinkButtonProps): import("react").JSX.Element;
export type TableCellAsyncState = "content" | "loading" | "failed";
export interface TableCellAsyncProps {
    /** `content` 由调用方提供内容；`loading` / `failed` 为单元格自身状态。 */
    state: TableCellAsyncState;
    /** 成功加载后的单元格内容。 */
    children?: ReactNode;
    /** 失败状态的刷新回调；由调用方负责发起请求并更新 `state`。 */
    onRefresh?: () => void;
    /** 失败文案，默认「加载失败」。 */
    failedText?: ReactNode;
    /** 刷新入口文案，默认「刷新」。 */
    refreshLabel?: ReactNode;
}
/**
 * 表格单元格异步状态：内容、加载、失败刷新。
 * 不接管请求：宿主通过 `state` 和 `onRefresh` 自行管理「失败 → 刷新 → 加载 → 内容」闭环。
 */
export declare function TableCellAsync({ state, children, onRefresh, failedText, refreshLabel, }: TableCellAsyncProps): import("react").JSX.Element;
export interface TableEllipsisProps {
    children: ReactNode;
}
/** 表格长文本：省略显示，hover 时使用 SensTips 展示完整内容。 */
export declare function TableEllipsis({ children }: TableEllipsisProps): import("react").JSX.Element;
export interface TableActionsProps {
    items: TableActionItem[];
}
/** 操作列：≤3 个平铺；>3 个时第 3 个起收进「更多」 */
export declare function TableActions({ items }: TableActionsProps): import("react").JSX.Element;
