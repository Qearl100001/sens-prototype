/** 页面级异常类型（Figma 4372:25723） */
export type PageEmptyType = "notFound" | "networkError" | "searchNoResult" | "noData" | "noPermission";
/** 非页面级异常类型（Figma 4372:25735） */
export type NonPageEmptyType = "networkError" | "noResult" | "noPermission" | "noData" | "loadFailed";
/**
 * @deprecated 兼容 Table / SelectDropdown；等同 `NonPageEmptyType` 的子集特殊尺寸映射。
 * 新代码优先用 `resolveEmptyStateIllustration`。
 */
export type NonPageEmptyIllustrationKey = Extract<NonPageEmptyType, "noResult" | "loadFailed" | "noData">;
export declare const PAGE_EMPTY_ILLUSTRATIONS: Record<PageEmptyType, string>;
export declare const NON_PAGE_EMPTY_ILLUSTRATIONS: Record<NonPageEmptyType, string>;
/** 特殊尺寸展示仍用 100px 源图，CSS 缩放到 50px */
export declare const NON_PAGE_EMPTY_ILLUSTRATIONS_SPECIAL: Record<NonPageEmptyType, string>;
/**
 * 兼容旧消费方（SelectDropdownEmpty / TableShell）。
 * 映射到非页面级特殊尺寸资产。
 */
export declare const EMPTY_STATE_ILLUSTRATIONS: Record<NonPageEmptyIllustrationKey, string>;
export type EmptyStateScope = "page" | "non-page";
export type PageEmptySize = "large" | "small";
export type NonPageEmptySize = "base" | "special";
export declare function resolveEmptyStateIllustration(scope: "page", type: PageEmptyType, _size?: PageEmptySize): string;
export declare function resolveEmptyStateIllustration(scope: "non-page", type: NonPageEmptyType, size?: NonPageEmptySize): string;
