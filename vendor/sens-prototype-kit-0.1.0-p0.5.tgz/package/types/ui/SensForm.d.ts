import { type HTMLAttributes, type ReactNode } from "react";
import "./form.css";
export type SensFormLayout = "vertical" | "horizontal";
export type SensFormLabelAlign = "control" | "top";
export interface SensFormProps extends HTMLAttributes<HTMLDivElement> {
    layout?: SensFormLayout;
    labelWidth?: number | string;
}
export interface SensFormItemProps extends HTMLAttributes<HTMLDivElement> {
    label?: ReactNode;
    /** DOM id used to associate the label and field. Generated when omitted for a direct control child. */
    controlId?: string;
    /** Submission key forwarded to a direct control child; do not derive it from the visible label. */
    name?: string;
    required?: boolean;
    optional?: ReactNode;
    labelHelp?: ReactNode;
    labelExtra?: ReactNode;
    labelAlign?: SensFormLabelAlign;
    description?: ReactNode;
    error?: ReactNode;
    counter?: ReactNode;
    layout?: SensFormLayout;
    labelWidth?: number | string;
    controlExtra?: ReactNode;
}
export interface SensFormActionsProps extends HTMLAttributes<HTMLDivElement> {
    alignWithControl?: boolean;
    labelWidth?: number | string;
}
export declare function SensForm({ layout, labelWidth, className, style, children, ...rootProps }: SensFormProps): import("react").JSX.Element;
export declare function SensFormItem({ label, controlId, name, required, optional, labelHelp, labelExtra, labelAlign, description, error, counter, layout, labelWidth, controlExtra, className, style, children, ...rootProps }: SensFormItemProps): import("react").JSX.Element;
export declare function SensFormActions({ alignWithControl, labelWidth, className, style, children, ...rootProps }: SensFormActionsProps): import("react").JSX.Element;
