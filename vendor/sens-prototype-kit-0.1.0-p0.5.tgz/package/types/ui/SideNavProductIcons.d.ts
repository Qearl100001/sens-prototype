import type { CSSProperties } from "react";
export interface SideNavProductIconProps {
    size?: number;
    className?: string;
    style?: CSSProperties;
    color?: string;
}
/** Figma side-nav · 默认图标 2 · `default-2` */
export declare function Default2SideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 默认图标 3 · `default-3` */
export declare function Default3SideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 默认图标 · `default` */
export declare function DefaultSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 概览 · `sa-dashboard` */
export declare function SaDashboardSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 业务集市 · `sa-dataset` */
export declare function SaDatasetSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 调试设备管理 · `sa-debugging-equipment` */
export declare function SaDebuggingEquipmentSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 管理中心 · `sa-management` */
export declare function SaManagementSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 报表 · `sa-report` */
export declare function SaReportSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 试验层 · `sa-test-ceng` */
export declare function SaTestCengSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 试验指标管理 · `sa-test-indicator` */
export declare function SaTestIndicatorSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 试验列表 · `sa-test-list` */
export declare function SaTestListSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 资产 · `sat-ad-assets` */
export declare function SatAdAssetsSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 管理与配置 · `sat-ad-management-config` */
export declare function SatAdManagementConfigSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 推广 · `sat-ad-promote` */
export declare function SatAdPromoteSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 概览 · `sat-dashboard` */
export declare function SatDashboardSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 报表 · `sat-report` */
export declare function SatReportSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 工具 · `sat-tools` */
export declare function SatToolsSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 审批数据管理 · `sbp-approval-data-manage` */
export declare function SbpApprovalDataManageSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 已办 · `sbp-approval-finish` */
export declare function SbpApprovalFinishSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 已发起 · `sbp-approval-initiate` */
export declare function SbpApprovalInitiateSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 审批配置 · `sbp-approval-setting` */
export declare function SbpApprovalSettingSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 审批开关 · `sbp-approval-switch` */
export declare function SbpApprovalSwitchSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 待办 · `sbp-approval-todo` */
export declare function SbpApprovalTodoSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 发件箱管理 · `sbp-email-manage` */
export declare function SbpEmailManageSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 操作日志 · `sbp-operation-log` */
export declare function SbpOperationLogSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 全局信息 · `sbp-overview` */
export declare function SbpOverviewSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 平台设置 · `sbp-security-setting` */
export declare function SbpSecuritySettingSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 业务资源 · `sbp-workload-biz-assets` */
export declare function SbpWorkloadBizAssetsSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 查询任务 · `sbp-workload-query-task` */
export declare function SbpWorkloadQueryTaskSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 内容中心 · `scms-center` */
export declare function ScmsCenterSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 内容配置 · `scms-setting` */
export declare function ScmsSettingSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 社群运营 · `scrm-community-operation` */
export declare function ScrmCommunityOperationSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 客户管理 · `scrm-customer-management` */
export declare function ScrmCustomerManagementSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 营销获客 · `scrm-marketing-customer` */
export declare function ScrmMarketingCustomerSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 营销任务 · `scrm-marketing-tasks` */
export declare function ScrmMarketingTasksSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 素材管理 · `scrm-material-management` */
export declare function ScrmMaterialManagementSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 工作提醒 · `scrm-work-notify` */
export declare function ScrmWorkNotifySideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 数据接入 · `sdg-warehousing` */
export declare function SdgWarehousingSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 数据表 · `sdh-data-model-table-manage` */
export declare function SdhDataModelTableManageSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 营销策略 · `sf-active-marketing` */
export declare function SfActiveMarketingSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 场景赋能 · `sf-scene` */
export declare function SfSceneSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 资源位运营 · `sf-section` */
export declare function SfSectionSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
/** Figma side-nav · 微信互动配置 · `sf-wechat` */
export declare function SfWechatSideNavIcon(props: SideNavProductIconProps): import("react").JSX.Element;
