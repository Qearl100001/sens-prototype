export type SelectDropdownLoadMoreState = "more" | "loading" | "error";
export interface SelectDropdownLoadMoreProps {
    state: SelectDropdownLoadMoreState;
    interactive?: boolean;
    onLoadMore?: () => void;
    onRetry?: () => void;
}
export declare function SelectDropdownLoadMore({ state, interactive, onLoadMore, onRetry, }: SelectDropdownLoadMoreProps): import("react").JSX.Element;
