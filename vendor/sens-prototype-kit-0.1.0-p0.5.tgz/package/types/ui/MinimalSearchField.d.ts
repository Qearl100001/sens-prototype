import { type InputProps } from "antd";
import { type CSSProperties } from "react";
import "./search.css";
export type MinimalSearchLineTone = "default" | "primary" | "active";
export interface MinimalSearchFieldProps extends Omit<InputProps, "prefix" | "allowClear" | "variant" | "width" | "size" | "disabled"> {
    width?: number | string;
    /** 右侧「创建」链接；默认 false */
    showCreate?: boolean;
    createLabel?: string;
    onCreate?: () => void;
    /** 仅禁用「创建」；搜索本身无禁用态 */
    createDisabled?: boolean;
    onBack?: () => void;
    showBackWhenFilled?: boolean;
    /** 禁止占位符截断时的 Tips；下拉浮层搜索通常不需要重复提示 */
    disablePlaceholderTip?: boolean;
    className?: string;
    style?: CSSProperties;
}
/** Figma 1601:10979 · 搜索区底线：悬停 primary，聚焦/点击 active */
export declare function resolveMinimalSearchLineTone(params: {
    searchFocused: boolean;
    searchPressed: boolean;
    createPressed: boolean;
    hoverZone: "search" | "create" | null;
    showCreate: boolean;
}): MinimalSearchLineTone;
/** Figma 1601:10979 / 3876:13525 · 分类区文案/箭头色（底线不变灰） */
export declare function resolveMinimalSelectorLineTone(params: {
    hovered: boolean;
    pressed: boolean;
    open: boolean;
}): MinimalSearchLineTone;
/**
 * 简约搜索：底部分割线 + 有输入时返回键（Figma 8099:27068 / 8116:29015）。
 */
export declare function MinimalSearchField({ width, showCreate, createLabel, onCreate, createDisabled, onBack, showBackWhenFilled, disablePlaceholderTip, className, style, placeholder, value, defaultValue, onChange, onFocus, onBlur, ...rest }: MinimalSearchFieldProps): import("react").JSX.Element;
