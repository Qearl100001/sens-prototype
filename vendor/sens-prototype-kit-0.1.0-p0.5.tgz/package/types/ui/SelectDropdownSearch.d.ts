import { type MinimalSearchFieldProps } from "./MinimalSearchField";
export interface SelectDropdownSearchProps extends Omit<MinimalSearchFieldProps, "showCreate" | "width"> {
}
/** 浮层内搜索：薄封装 MinimalSearchField · 实时·简约 · 有输入显示返回 */
export declare function SelectDropdownSearch({ placeholder, className, onBack, disablePlaceholderTip, ...rest }: SelectDropdownSearchProps): import("react").JSX.Element;
