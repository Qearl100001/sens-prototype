import type { DefaultOptionType } from "antd/es/select";
import { defaultSelectOptionMatcher, getOptionLabel, getOptionSearchText, type OptionSearchIndexEntry, type SelectOptionFilterMatcher } from "./matchSelectOption";
export type SelectDropdownSearchMode = "local" | "remote";
export type SelectDropdownDataStatus = "idle" | "loading" | "ready" | "failed";
export type SelectDropdownSearchStatus = "idle" | "debouncing" | "searching" | "done";
export type SelectDropdownContentPhase = "fullList" | "searching" | "hasResults" | "noResults" | "dataLoading" | "emptyData" | "loadFailed";
export interface UseSelectDropdownSearchOptions {
    searchable: boolean;
    searchMode: SelectDropdownSearchMode;
    searchDebounce: number;
    options?: DefaultOptionType[];
    loading?: boolean;
    optionsLoadFailed?: boolean;
    onSearch?: (query: string) => void;
    filterMatcher?: SelectOptionFilterMatcher;
}
export interface UseSelectDropdownSearchResult {
    query: string;
    setQuery: (value: string) => void;
    resetSearch: () => void;
    dataStatus: SelectDropdownDataStatus;
    searchStatus: SelectDropdownSearchStatus;
    contentPhase: SelectDropdownContentPhase;
    displayOptions: DefaultOptionType[];
    resultCount: number;
    sourceCount: number;
    showOptionList: boolean;
    /** 与 sourceOptions 同步的预计算索引（供性能验收） */
    searchIndex: OptionSearchIndexEntry[];
}
export declare function resolveSelectDropdownContentPhase(params: {
    dataStatus: SelectDropdownDataStatus;
    query: string;
    searchStatus: SelectDropdownSearchStatus;
    resultCount: number;
    sourceEmpty: boolean;
}): SelectDropdownContentPhase;
export declare function useSelectDropdownSearch({ searchable, searchMode, searchDebounce, options, loading, optionsLoadFailed, onSearch, filterMatcher, }: UseSelectDropdownSearchOptions): UseSelectDropdownSearchResult;
export { defaultSelectOptionMatcher, getOptionLabel, getOptionSearchText };
