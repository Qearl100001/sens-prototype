import { type CSSProperties, type ReactNode } from "react";
export type TagVariant = "multicolor" | "overlay" | "status";
export type TagColor = "neutral" | "red" | "yellow" | "green" | "cyan" | "blue" | "purple";
export type TagSize = "large" | "small";
/** 状态标签五语义；颜色固定，不可用多色色系替换 */
export type TagStatus = "success" | "processing" | "exception" | "error" | "invalid";
/** 多色/操作标签视觉态；disabled / disabledHover 仅多色标签生效 */
export type TagInteractiveState = "default" | "hover" | "active" | "disabled" | "disabledHover";
/** 移除图标交互态（热区在关闭钮，与标签体悬停无关） */
export type TagCloseState = "default" | "hover" | "active" | "disabled" | "disabledHover";
export declare const TAG_STATUS_LABEL: Record<TagStatus, string>;
export type SensTagProps = {
    variant: TagVariant;
    /** multicolor / 操作态；overlay 忽略；status 勿用，改传 status */
    color?: TagColor;
    /** 仅 variant="status"；默认 success */
    status?: TagStatus;
    /** 默认 large */
    size?: TagSize;
    /** status / overlay 下忽略 */
    clickable?: boolean;
    /** status / overlay 下忽略 */
    closable?: boolean;
    /** status / overlay 下忽略；仅禁用关闭图标，不改变标签本体禁用态 */
    closeDisabled?: boolean;
    /** status / overlay 下忽略 */
    icon?: ReactNode;
    /** status / overlay 下忽略 */
    extra?: ReactNode;
    /** status / overlay 下忽略；显示帮助图标热区，使用 SensTips 承载 */
    helpMessage?: ReactNode;
    /** status / overlay 下忽略；显示警告 / 报错图标热区，使用 SensTips 承载 */
    errorMessage?: ReactNode;
    onClick?: () => void;
    onClose?: () => void;
    /** status / overlay 下忽略 */
    disabled?: boolean;
    /** 禁止标签文字自身的悬停便签；帮助 / 错误图标便签不受影响 */
    labelTipsDisabled?: boolean;
    /**
     * 仅预览板静态样张：强制套某交互态 token，不响应真实悬停。
     * 真实业务勿传。
     */
    previewState?: TagInteractiveState;
    /** 仅预览板：强制移除图标态 */
    previewCloseState?: TagCloseState;
    children?: ReactNode;
    className?: string;
    style?: CSSProperties;
};
/**
 * 多色 / 中性表面色。固定色板，不参与功能色换肤。
 * 中性可点悬停/点击 → 冰绽蓝 02/03 + 文字&图标。
 */
export declare function resolveTagInteractiveSurface(color: TagColor, state: TagInteractiveState): {
    background: string;
    color: string;
};
/**
 * 移除图标色（Figma close 15018:40157）。
 * 默认中性图标；悬停/点击走警告红；禁用走 icon disable α。
 * 叠加默认白；悬停/点击仍警告红（删除反馈）。
 */
export declare function resolveTagCloseColor(state: TagCloseState, options?: {
    overlay?: boolean;
}): string;
/**
 * status：五语义；圆点=状态色、文案=中性色；仅进行中圆点带 link-color @0.2 外描边；无点击/移除/禁用。
 * multicolor：固定色板；仅 clickable 时悬停/点击切 背景/02|03 + 文字&图标；中性可点走冰绽蓝。
 * overlay：纯展示叠加，不接图标 / 帮助 / 警告 / 点击 / 移除 / 禁用。
 * closable：移除图标独立热区；默认 icon / 悬停 warning / 点击 warning-active；资产 `SensIcon name="close"`。
 */
export declare function SensTag({ variant, color, status, size, clickable, closable, closeDisabled, icon, extra, helpMessage, errorMessage, onClick, onClose, disabled, labelTipsDisabled, previewState, previewCloseState, children, className, style, }: SensTagProps): import("react").JSX.Element;
/** 预览页：六种类型 × 大/小；状态五语义；多色交互；移除图标态 */
export declare function TagTypesPreview(): import("react").JSX.Element;
