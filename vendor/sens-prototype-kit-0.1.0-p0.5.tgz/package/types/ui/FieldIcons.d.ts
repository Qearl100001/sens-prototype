import type { CSSProperties } from "react";
export declare const INPUT_ERROR_ICON_SIZE_M: number;
export declare const INPUT_ERROR_ICON_SIZE_S: number;
export declare const INPUT_ERROR_HELP_ICON_SIZE: number;
/** Figma 17694:64400 / 3729:15820 · 下拉已选勾选 */
export declare const SELECT_CHECK_ICON_SIZE: number;
export declare const STEPPER_ICON_SIZE = 10;
export interface IconProps {
    size?: number;
    className?: string;
    style?: CSSProperties;
    color?: string;
}
/** Figma 1536:5443 / 1499:5472 · 报错菱形（输入框警告） */
export declare function ErrorDiamondIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1499:5473 · 反馈状态 / info */
export declare function FeedbackInfoIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1499:5470 · 反馈状态 / complete */
export declare function FeedbackCompleteIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1499:5471 · 反馈状态 / warning */
export declare function FeedbackWarningIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1499:5472 · 反馈状态 / error */
export declare function FeedbackErrorIcon(props: IconProps): import("react").JSX.Element;
/** Figma 803:196 · help（说明 / 帮助 / 注释） */
export declare function HelpIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1471:5057 · icon-default（链接按钮示例图标，非选择器箭头） */
export declare function IconDefaultIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 804:78 · Select 触发框默认箭头（down） */
export declare const SELECT_ARROW_ICON_SIZE: number;
/** Figma 1430:4796 · Select 触发框清空（16×16，与 Input allowClear 同源） */
export declare const SELECT_CLEAR_ICON_SIZE: number;
/** Select 触发框默认箭头 · 复用 ChevronDownIcon（Figma 15474:48966 / 804:78） */
export declare function SelectArrowIcon(props: IconProps): import("react").JSX.Element;
/** Figma 1430:4796 · Select 触发框清空（与 Input allowClear 同源） */
export declare function SelectClearIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 17694:64400 / 3729:15820 · 下拉浮层已选勾选（16×16 描边对勾） */
export declare function SelectCheckIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 17460:62565 / 17460:62566 · 数字输入框步进器箭头 */
export declare function StepperUpIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 17460:62566 / 2535:10559 · 数字输入框步进器向下（10×10 容器内 6.67×3.89 圆角三角） */
export declare function StepperDownIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 803:199 · 顶部导航帮助中心 */
export declare function NavHelpcenterIcon(props: IconProps): import("react").JSX.Element;
/** Figma 803:174 · 顶部导航通知 */
export declare function NavNoticeIcon(props: IconProps): import("react").JSX.Element;
/** Figma 803:177 · 顶部导航平台 */
export declare function NavPlatformIcon(props: IconProps): import("react").JSX.Element;
/** Figma 4934:15929 · 顶部导航资源管理 */
export declare function NavWorkloadManagerIcon(props: IconProps): import("react").JSX.Element;
/** Figma 4934:15931 · 顶部导航审批 */
export declare function NavExamineIcon(props: IconProps): import("react").JSX.Element;
/** Figma 7576:28035 · 顶部导航语言 */
export declare function NavLanguageIcon(props: IconProps): import("react").JSX.Element;
/** Figma 803:283 · 顶部导航产品切换 */
export declare function NavProductNavigationIcon(props: IconProps): import("react").JSX.Element;
/** Figma 804:78 · 顶部导航向下箭头 */
export declare function NavDownIcon(props: IconProps): import("react").JSX.Element;
/** Figma 1777:111170 · 侧导航二级模块向下箭头 */
export declare function SideNavDownIcon(props: IconProps): import("react").JSX.Element;
/** Figma 1777:111170 · 侧导航二级模块向上箭头 */
export declare function SideNavUpIcon(props: IconProps): import("react").JSX.Element;
/** Figma 1777:111170 · 侧导航更多推荐链接 */
export declare function SideNavLinkIcon(props: IconProps): import("react").JSX.Element;
/** Figma 1777:111170 · 侧导航锁定后的收起按钮 */
export declare function SideNavCollapseIcon(props: IconProps): import("react").JSX.Element;
/** Figma 1777:111170 · 侧导航紧凑态展开按钮，和收起按钮成对使用。 */
export declare function SideNavExpandIcon(props: IconProps): import("react").JSX.Element;
/** Figma 1777:111158 · 侧导航未锁定按钮 */
export declare function SideNavUnpinIcon(props: IconProps): import("react").JSX.Element;
/** Figma 1777:111161 · 侧导航锁定按钮 */
export declare function SideNavPinIcon(props: IconProps): import("react").JSX.Element;
/** Figma 18354:71233 · 侧导航单层项 / 基本设置 */
export declare function SbpSettingSideNavIcon(props: IconProps): import("react").JSX.Element;
/** Figma 18354:71253 · 侧导航单层项 / 成员管理 */
export declare function SbpMemberSideNavIcon(props: IconProps): import("react").JSX.Element;
/** Figma 18354:71275 · 侧导航单层项 / 角色管理 */
export declare function SbpRoleSideNavIcon(props: IconProps): import("react").JSX.Element;
/** Figma 19820:2058 · 侧导航二级分组 / 埋点数据接入 */
export declare function SdiWarehousingDataIngestionIcon(props: IconProps): import("react").JSX.Element;
/** Figma 19820:2061 · 侧导航二级分组 / 通用数据接入 */
export declare function SdhWarehousingGeneralDataIngestionIcon(props: IconProps): import("react").JSX.Element;
/** Figma 18354:71272 · 侧导航二级分组 / 元数据管理 */
export declare function SdhDataModelUserEntityManageIcon(props: IconProps): import("react").JSX.Element;
/** Figma 18354:71273 · 侧导航二级分组 / 实体配置 */
export declare function SdhEntityConfIcon(props: IconProps): import("react").JSX.Element;
/** Figma 18354:71267 · 侧导航二级分组 / 数据质量 */
export declare function SdgDataQualityIcon(props: IconProps): import("react").JSX.Element;
/** Figma 18527:121296 · 分析专属侧导虚拟二级 / 行为分析 */
export declare function SaBehaviorAnalysisSideNavIcon(props: IconProps): import("react").JSX.Element;
/** Figma 18527:121302 · 分析专属侧导虚拟二级 / 用户分析 */
export declare function SaUserAnalysisSideNavIcon(props: IconProps): import("react").JSX.Element;
/** Figma 18535:100610 · 分析专属侧导虚拟二级 / 经营分析 */
export declare function SaBusinessAnalysisSideNavIcon(props: IconProps): import("react").JSX.Element;
/** Figma 1724:111294 · 分析专属侧导虚拟二级 / 其他 */
export declare function SaOtherSideNavIcon(props: IconProps): import("react").JSX.Element;
/** Figma 804:81 · left 箭头向左（简约搜索返回 · 8116:29008 链接按钮） */
export declare function ChevronLeftIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 804:80 · right 箭头向右（分页器下一页） */
export declare function ChevronRightIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 16114:56177 · expand-and-collapse-arrow-left（分页器向前 5 页） */
export declare function DoubleChevronLeftIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 16114:56178 · expand-and-collapse-arrow-right（分页器向后 5 页） */
export declare function DoubleChevronRightIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 804:78 / 804:82 · 箭头向下（选择器 / 更多下拉 / 筛选收起态） */
export declare function ChevronDownIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 804:79 / 804:83 · 箭头向上（选择器 / 更多下拉 / 筛选展开态） */
export declare function ChevronUpIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 804:82 · 筛选展开按钮线性下箭头 */
export declare function FilterChevronDownIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 804:83 · 筛选收起按钮线性上箭头 */
export declare function FilterChevronUpIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 805:58 · close 关闭叉子 */
export declare function CloseIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1430:4796 · 一键清除 */
export declare function CloseCircleIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 16211:56216 · 编辑器加号（editor-add） */
export declare function EditorAddIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 3729:15820 · 对勾（checkbox / 选中） */
export declare function CheckIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 813:242 · 复选框专用对勾 */
export declare function CheckboxCheckIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1335:6442 / 10282:33385 · 重命名铅笔（rename） */
export declare function RenameIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1499:5471 · 警告面性（warning-filled） */
export declare function WarningFilledIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1853:6583 · 纵向拖拽（drag-vertical） */
export declare function DragVerticalIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 803:278 · 刷新 / 重新加载（reload） */
export declare function ReloadIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 1650:7139 · 设置（setting） */
export declare function SettingIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
/** Figma 803:276 · 更多（more） */
export declare function MoreIcon({ size, className, style, color, }: IconProps): import("react").JSX.Element;
