export interface HighlightSegment {
    text: string;
    highlight: boolean;
}
/** 大小写不敏感字面子串匹配，全部命中段高亮。仅字面高亮；拼音/首字母过滤命中不在此处理。 */
export declare function splitByKeyword(text: string, keyword: string): HighlightSegment[];
export interface SearchHighlightProps {
    text: string;
    keyword: string;
    className?: string;
}
/** 关键词高亮：仅 label 字面子串；拼音过滤命中不高亮。仅 component-primary，禁 dangerouslySetInnerHTML */
export declare function SearchHighlight({ text, keyword, className }: SearchHighlightProps): import("react").JSX.Element;
