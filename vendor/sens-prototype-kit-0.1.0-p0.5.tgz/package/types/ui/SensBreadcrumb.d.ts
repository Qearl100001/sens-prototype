import { type CSSProperties, type ReactNode } from "react";
import "./breadcrumb.css";
export interface SensBreadcrumbItem {
    key: string;
    label: ReactNode;
    onClick?: () => void;
}
export interface SensBreadcrumbProps {
    items: SensBreadcrumbItem[];
    ellipsis?: boolean;
    className?: string;
    style?: CSSProperties;
}
export declare function SensBreadcrumb({ items, ellipsis, className, style }: SensBreadcrumbProps): import("react").JSX.Element;
