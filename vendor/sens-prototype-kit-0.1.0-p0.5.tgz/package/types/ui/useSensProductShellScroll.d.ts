import { type UIEvent } from "react";
/** 内容区超过该阈值后收起顶导并显示回到顶部。 */
export declare const SENS_PRODUCT_SHELL_SCROLL_THRESHOLD = 300;
/** 停滚且未悬停后，回到顶部按钮收起到半圆的闲置时长。 */
export declare const SENS_PRODUCT_SHELL_BACK_TOP_IDLE_MS = 3000;
export declare function useSensProductShellScroll(): {
    scrollRef: import("react").RefObject<HTMLDivElement>;
    contentRef: import("react").RefObject<HTMLElement>;
    topNavCollapsed: boolean;
    titleBarElevated: boolean;
    showBackTop: boolean;
    backTopDocked: boolean;
    handleContentScroll: (event: UIEvent<HTMLDivElement>) => void;
    handleBackToTop: () => void;
    handleBackTopPointerEnter: () => void;
    handleBackTopPointerLeave: () => void;
};
