import { type SelectProps } from "antd";
import type { DefaultOptionType } from "antd/es/select";
import { type CSSProperties, type ReactNode } from "react";
import { type FunctionalSkin } from "../design-system/functional-skin";
import { type SelectOptionFilterMatcher } from "./matchSelectOption";
import { type SensInputReadOnlyVariant, type SensInputWarningPlacement } from "./SensInput";
import { type SelectDropdownLoadMoreState } from "./SelectDropdownLoadMore";
import { type SelectDropdownSearchMode } from "./useSelectDropdownSearch";
import "./select-dropdown.css";
import "./select-dropdown-preview.css";
import "./select-trigger.css";
import "./select-trigger-preview.css";
export declare const SELECT_OPTION_HEIGHT = 34;
/** 选项列表最多露出 9.5 行，超出滚动；不含搜索 / 统计 / 操作条 */
export declare const SELECT_OPTION_VISIBLE_ROWS = 9.5;
export declare const SELECT_LIST_MAX_HEIGHT: number;
export declare const SELECT_DROPDOWN_MATRIX_CELL_WIDTH = 160;
export declare const SELECT_DROPDOWN_CONTENT_MATRIX_CELL_WIDTH = 200;
export declare const SELECT_DROPDOWN_DEMO_WIDTH = 200;
export declare const SELECT_TRIGGER_MATRIX_CELL_WIDTH = 200;
export declare const SELECT_ADAPTIVE_MIN_WIDTH = 148;
export declare const SELECT_ADAPTIVE_MAX_WIDTH = 600;
/** 多选浮层最小宽（Figma `17728:81940`）；单选不套这条 */
export declare const SELECT_MULTIPLE_POPUP_MIN_WIDTH = 320;
export declare const SELECT_FIXED_WIDTH_PRESETS: {
    readonly "128": 128;
    readonly "148": 148;
    readonly "320": 320;
    readonly "600": 600;
};
export type SensSelectWidthPreset = keyof typeof SELECT_FIXED_WIDTH_PRESETS;
export type SensSelectWidthMode = "adaptive";
/** 个数型回显封顶 */
export declare const SELECT_COUNT_MAX = 999;
/** 展示型多行换行上限（Figma `15584:52788` / `15584:52911`）；单行仍锁 32 */
export declare const SELECT_TAGS_MAX_HEIGHT = 128;
/** 标签文案区最大宽（省略发生在文案上，Figma `15584:52711`） */
export declare const SELECT_TAG_LABEL_MAX_WIDTH = 112;
/**
 * 可移除标签整颗最大宽：左右 8 + 文案 112 + gap 4 + × 14 = 146
 * （Figma 长标实例宽 146；勿把 112 套在根节点上）
 */
export declare const SELECT_TAG_CHIP_MAX_WIDTH = 146;
export declare const SELECT_TAGS_MATRIX_CELL_WIDTH = 320;
export type SensSelectMultiDisplay = "count" | "tags";
/** 下拉选项可选的辅助文案；单选、多选共用同一套双行选项结构。 */
export type SensSelectOption = DefaultOptionType & {
    description?: ReactNode;
    icon?: ReactNode;
};
/** R3 触发框 CSS 变量（字段色与 SensInput 同源；视觉直读 design token） */
export declare function useSensSelectTriggerStyle(size?: SelectProps["size"]): CSSProperties;
/** 浮层 CSS 变量（portaled popup 须经 styles.popup 注入）。未传 skin 时跟 AppearanceProvider，无 Provider 回落绿。 */
export declare function useSensSelectDropdownStyle(skin?: FunctionalSkin): CSSProperties;
export type SensSelectDropdownGroupStyle = "title" | "divider";
export interface SensSelectDropdownProps extends Omit<SelectProps, "options"> {
    /** 未传则跟当前 Functional Skin；勾选色固定中性图标，不换肤 */
    functionalSkin?: FunctionalSkin;
    /** 浮层内搜索（R2）。多选确认菜单默认开启，选择器调用即可 */
    searchable?: boolean;
    searchMode?: SelectDropdownSearchMode;
    searchDebounce?: number;
    /** 预留：触发型搜索，R2 不实现 */
    searchTrigger?: "realtime" | "enter";
    resetSearchOnClose?: boolean;
    /** remote：空 query 不调用 */
    onSearch?: (query: string) => void;
    /** 源数据加载失败（打开浮层未拉到选项） */
    optionsLoadFailed?: boolean;
    onEmptyAction?: () => void;
    /** 增量加载：列表底部的加载更多 / 加载中 / 加载失败状态。 */
    loadMoreState?: SelectDropdownLoadMoreState;
    onLoadMore?: () => void;
    onLoadMoreRetry?: () => void;
    /** 覆盖本地默认匹配（原文/全拼/首字母/searchText） */
    filterMatcher?: SelectOptionFilterMatcher;
    /** R3：悬停显示清空 × */
    clearable?: boolean;
    /** R3：框内/框外警告 */
    warningPlacement?: SensInputWarningPlacement;
    help?: ReactNode;
    warningMessage?: ReactNode;
    /** 固定宽三档：选中前后保持同宽；特殊宽度由具体场景另行确认 */
    widthPreset?: SensSelectWidthPreset;
    /** 自适应宽：min 148 / max 600，随内容增长 */
    widthMode?: SensSelectWidthMode;
    /** 多选回显：`count` 个数型；`tags` 展示型标签。默认浮层走复选确认 */
    multiDisplay?: SensSelectMultiDisplay;
    /**
     * 多选是否「完成才回显」。默认 true（有操作栏）。
     * 展示型确认：触发框只显示已提交；菜单改草稿；点「完成」收起后才上屏。
     * `false`：无操作栏，勾选即时写入触发框。
     */
    confirmMultiple?: boolean;
    /** 简约型：无边框触发框，仅单选；浮层仍走单选下拉 */
    appearance?: "simple";
    /**
     * 展示型标签是否多行换行。默认 false：单行 32px，放不下用「…共 N 项」（N=已选总数）。
     * true：换行，min 32 / max 128，超出滚动，展示全部标签。
     */
    tagsWrap?: boolean;
    /** 展示型只读：`filled` 只读_背景 / `plain` 只读_字段。表单详情用，不展开浮层 */
    readOnlyVariant?: SensInputReadOnlyVariant;
    /**
     * 带层级分组：`title` 灰底标题（面性），`divider` 组间通栏线（线性）。
     * 仅对 `options` 里带 `options` 的 OptGroup 生效；有搜索词时打平，不显示分组。
     */
    groupStyle?: SensSelectDropdownGroupStyle;
    /** 选项可提供 description，渲染为主文案下方的辅助文案。 */
    options?: SensSelectOption[];
}
/** 基础单选 Select + 浮层 token（R1 容器/行 + R2 搜索 + R3 触发框） */
export declare function SensSelectDropdown({ functionalSkin, searchable: searchableProp, searchMode, searchDebounce, resetSearchOnClose, onSearch, optionsLoadFailed, onEmptyAction, loadMoreState, onLoadMore, onLoadMoreRetry, filterMatcher, clearable, warningPlacement, help, warningMessage, widthPreset, widthMode, multiDisplay, confirmMultiple, appearance, groupStyle, tagsWrap, readOnlyVariant, tagRender, className, style, size, status: statusProp, classNames, styles, menuItemSelectedIcon, options, loading, popupRender, optionRender, onOpenChange, showSearch, filterOption, suffixIcon: suffixIconProp, allowClear: allowClearProp, mode: modeProp, maxTagCount: maxTagCountProp, maxTagPlaceholder: maxTagPlaceholderProp, onChange, value, defaultValue, disabled, open: openProp, defaultOpen, popupMatchSelectWidth: popupMatchSelectWidthProp, placeholder, listHeight: listHeightProp, listItemHeight: listItemHeightProp, ...props }: SensSelectDropdownProps): import("react").JSX.Element;
export type SelectDropdownPreviewState = "default" | "hover" | "click" | "disabled" | "disabledHover";
export interface SelectDropdownStatesPreviewProps {
    title?: ReactNode;
    functionalSkin?: FunctionalSkin;
}
/** 2 行 × 5 态 = 10 格 */
export declare function SelectDropdownStatesPreview({ title, functionalSkin, }: SelectDropdownStatesPreviewProps): import("react").JSX.Element;
/** 多选复选行 2 行 × 5 态。Figma `17685:60706` */
export declare function SelectMultipleOptionStatesPreview({ title, functionalSkin, }: SelectDropdownStatesPreviewProps): import("react").JSX.Element;
export type SelectDropdownContentPreviewPhase = "fullList" | "searching" | "hasResults" | "noResults" | "dataLoading" | "emptyData";
export interface SelectDropdownContentStatesPreviewProps {
    title?: ReactNode;
    functionalSkin?: FunctionalSkin;
}
/** R2：内容区六面静态矩阵 */
export declare function SelectDropdownContentStatesPreview({ title, functionalSkin, }: SelectDropdownContentStatesPreviewProps): import("react").JSX.Element;
export type SelectTriggerPreviewState = "default" | "hover" | "focus" | "disabled" | "disabledHover" | "loading" | "loadingHover";
export interface SelectTriggerStatesPreviewProps {
    title?: ReactNode;
}
/** R3：触发框 3 警告 × 2 内容 × 5 态（仅 32px，无小尺寸） */
export declare function SelectTriggerStatesPreview({ title }: SelectTriggerStatesPreviewProps): import("react").JSX.Element;
export interface SelectCountTriggerStatesPreviewProps {
    title?: ReactNode;
}
/** 多选个数型：无 / 框内警告 / 框外警告 × 128 / 148 × 未选 / 已选 × 7 态（含禁用 / 加载） */
export declare function SelectCountTriggerStatesPreview({ title }: SelectCountTriggerStatesPreviewProps): import("react").JSX.Element;
export interface SelectSimpleTriggerStatesPreviewProps {
    title?: ReactNode;
}
/** 简约型：无 / 警告 × 未选 / 已选 × 6 态（禁用+警告无对应组件） */
export declare function SelectSimpleTriggerStatesPreview({ title }: SelectSimpleTriggerStatesPreviewProps): import("react").JSX.Element;
export interface SelectTagsTriggerStatesPreviewProps {
    title?: ReactNode;
}
/** 多选展示型：320 定宽 × 未选 / 已选 × 7 态 + 只读两档 */
export declare function SelectTagsTriggerStatesPreview({ title }: SelectTagsTriggerStatesPreviewProps): import("react").JSX.Element;
