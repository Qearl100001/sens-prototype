import type { NonPageEmptyType } from "./EmptyStateIllustrations";
export type SelectDropdownEmptyType = Extract<NonPageEmptyType, "noResult" | "loadFailed" | "noData">;
export interface SelectDropdownEmptyProps {
    type: SelectDropdownEmptyType;
    /** loadFailed → 刷新；noData → 添加（R2 仅展示 + 可选回调） */
    onAction?: () => void;
    className?: string;
}
/**
 * 浮层空态薄封装。内部消费 `<SensEmptyState scope="non-page" size="special" />`，
 * 对外 type / onAction 保持不变。
 */
export declare function SelectDropdownEmpty({ type, onAction, className }: SelectDropdownEmptyProps): import("react").JSX.Element;
