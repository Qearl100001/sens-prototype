import { type CSSProperties, type ReactElement, type ReactNode } from "react";
import "./popover.css";
export type SensPopoverPlacement = "top" | "bottom" | "left" | "right";
export type SensPopoverAlign = "start" | "center" | "end";
export type SensPopoverSize = "small" | "medium" | "large";
export type SensPopoverVariant = "browse" | "action" | "confirm";
export type SensPopoverStrategy = "portal" | "anchored";
export type SensPopoverProps = {
    children: ReactElement;
    title?: ReactNode;
    content: ReactNode;
    actions?: ReactNode;
    size?: SensPopoverSize;
    variant?: SensPopoverVariant;
    placement?: SensPopoverPlacement;
    align?: SensPopoverAlign;
    open?: boolean;
    defaultOpen?: boolean;
    disabled?: boolean;
    autoAdjust?: boolean;
    /** `anchored` 仅供设计状态矩阵稳定展示 12 个箭头位；业务使用默认 portal。 */
    strategy?: SensPopoverStrategy;
    onOpenChange?: (open: boolean) => void;
    className?: string;
    style?: CSSProperties;
};
/**
 * 点击触发的轻量浮层。与悬停说明 `SensTips` 分属两种语义：前者承载浏览/操作，后者只承载短说明。
 */
export declare function SensPopover({ children, title, content, actions, size, variant, placement, align, open: openProp, defaultOpen, disabled, autoAdjust, strategy, onOpenChange, className, style, }: SensPopoverProps): import("react").JSX.Element;
