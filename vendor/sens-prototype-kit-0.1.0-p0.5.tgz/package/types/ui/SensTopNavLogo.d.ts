import type { CSSProperties, ImgHTMLAttributes } from "react";
/** Figma 18530:73096 · Sensors Data 顶导 logo；白标，需放在顶导绿/蓝底上 */
export declare const SENS_TOP_NAV_LOGO_SRC = "/brand/sensors-data-logo.svg";
export declare const SENS_TOP_NAV_LOGO_WIDTH = 58;
export declare const SENS_TOP_NAV_LOGO_HEIGHT = 20;
export interface SensTopNavLogoProps extends Omit<ImgHTMLAttributes<HTMLImageElement>, "src" | "alt" | "width" | "height"> {
    style?: CSSProperties;
}
/**
 * 顶部导航左上角品牌 logo（Sensors Data）。
 * 尺寸固定 58×20，与 Figma logo 节点一致；颜色随 SVG 白填充。
 */
export declare function SensTopNavLogo({ style, ...rest }: SensTopNavLogoProps): import("react").JSX.Element;
