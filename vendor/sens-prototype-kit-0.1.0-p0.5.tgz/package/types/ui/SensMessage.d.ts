import { type CSSProperties, type ReactNode } from "react";
import { type MessageType } from "./feedbackShared";
export type { MessageType } from "./feedbackShared";
export { MESSAGE_TYPE_LABEL } from "./feedbackShared";
export type SensMessageProps = {
    type?: MessageType;
    closable?: boolean;
    link?: ReactNode;
    onClose?: () => void;
    children?: ReactNode;
    className?: string;
    style?: CSSProperties;
};
export type SensMessageLinkProps = {
    children?: ReactNode;
    href?: string;
    onClick?: () => void;
    className?: string;
    style?: CSSProperties;
    "aria-label"?: string;
};
/**
 * 轻提示内的链接按钮（常规）：Figma 1363:11431。
 * 纯文字 14/22，0 padding；不是 antd Button / 三级按钮。
 */
export declare function SensMessageLink({ children, href, onClick, className, style, "aria-label": ariaLabel, }: SensMessageLinkProps): import("react").JSX.Element;
/**
 * 轻提示 Message：白底 + D4↓ 浮层短反馈。
 * type 五档含 loading；状态色不换肤。
 */
export declare function SensMessage({ type, closable, link, onClose, children, className, style, }: SensMessageProps): import("react").JSX.Element;
/** 预览矩阵：type × 基础 / +关闭 / +链接 */
export declare function MessageTypesPreview(): import("react").JSX.Element;
