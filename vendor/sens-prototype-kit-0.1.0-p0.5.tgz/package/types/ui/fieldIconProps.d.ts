import type { CSSProperties, ReactNode } from "react";
/** Input / Select allowClear 清除图标（Figma 1430:4796） */
export declare function useSensAllowClear(): {
    clearIcon: import("react").JSX.Element;
};
/** Select 后缀：收起 down / 展开 up（Figma 804:78 / 804:79），互斥显示 */
export declare function SensSelectSuffix(): import("react").JSX.Element;
/** R3 主选择器触发框箭头（Figma 804:78 down / 804:79 up，互斥显示，中性色不变绿） */
export declare function SensSelectTriggerArrow(): import("react").JSX.Element;
/** Select 后缀箭头 props（搜索分类等；箭头中性，文案/描边走主色链） */
export declare function useSensSelectSuffixProps(extraStyle?: CSSProperties): {
    suffixIcon: import("react").JSX.Element;
    className: string;
    style: CSSProperties;
};
/** 触发框加载：三角换成转圈（Figma 1227:8989）；色走禁用箭头 token */
export declare function SensSelectLoadingIcon(): import("react").JSX.Element;
/** R3 触发框后缀：箭头在左、框内警告菱形在右（Figma 15474:49040） */
export declare function SensSelectTriggerSuffix({ insideWarning, loading, }: {
    insideWarning?: ReactNode;
    loading?: boolean;
}): import("react").JSX.Element;
/** R3 触发框 suffix（中性箭头，与搜索分类 hook 分离） */
export declare function useSensSelectTriggerSuffixProps(extraStyle?: CSSProperties, insideWarning?: ReactNode, loading?: boolean): {
    suffixIcon: import("react").JSX.Element;
    className: string;
    style: CSSProperties | undefined;
};
/** R3 触发框 props：箭头 + 可选 clearable + 可选框内警告 */
export declare function useSensSelectTriggerProps(clearable?: boolean, extraStyle?: CSSProperties, insideWarning?: ReactNode, loading?: boolean): {
    suffixIcon: import("react").JSX.Element;
    className: string;
    style: CSSProperties | undefined;
} | {
    allowClear: {
        clearIcon: import("react").JSX.Element;
    };
    suffixIcon: import("react").JSX.Element;
    className: string;
    style: CSSProperties | undefined;
};
/** 带设计系统图标的 Select 通用 props（含 allowClear） */
export declare function useSensSelectProps(): {
    allowClear: {
        clearIcon: import("react").JSX.Element;
    };
    suffixIcon: import("react").JSX.Element;
    className: string;
    style: CSSProperties;
};
/** 搜索前缀图标 + 图标/文字间距 CSS 变量（icons.md · spacing/1x） */
export declare function useSensSearchPrefix(): import("react").JSX.Element;
/** 任意带搜索前缀的 Input：className + 图标色 CSS 变量 */
export declare function useSensSearchFieldProps(extraStyle?: CSSProperties): {
    className: string;
    prefix: import("react").JSX.Element;
    style: CSSProperties;
};
