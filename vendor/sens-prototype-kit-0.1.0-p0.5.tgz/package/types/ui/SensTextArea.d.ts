import { type InputProps } from "antd";
import type { TextAreaProps } from "antd/es/input";
import type { CSSProperties, ReactNode } from "react";
import "./input.css";
import { type SensInputReadOnlyVariant, type SensInputWarningPlacement } from "./SensInput";
import "./textarea.css";
import "./textarea-preview.css";
import "./input-preview.css";
/** 文本域专有：4.5 行 minHeight + padding；颜色变量与 SensInput 同源 */
export declare function useSensTextAreaStyle(size?: InputProps["size"]): CSSProperties;
export type SensTextAreaWarningPlacement = SensInputWarningPlacement;
export type SensTextAreaReadOnlyVariant = SensInputReadOnlyVariant;
export interface SensTextAreaCountFormatterArgs {
    value: string;
    count: number;
    maxLength?: number;
}
/** 文本域框内计数：当前值超限时只把当前数字标红，最大值保持中性。 */
export declare function formatSensTextAreaCount({ count, maxLength, }: SensTextAreaCountFormatterArgs): ReactNode;
export interface SensTextAreaProps extends TextAreaProps {
    warningPlacement?: SensTextAreaWarningPlacement;
    help?: ReactNode;
    warningMessage?: ReactNode;
    /** 预览矩阵内部使用：静态样张不进入 live region */
    helpLive?: boolean;
    readOnlyVariant?: SensTextAreaReadOnlyVariant;
}
/** 多行文本输入框：4.5 行默认高度 + 框内/框外警告 + 只读态 */
export declare function SensTextArea({ className, style, size, status: statusProp, variant: variantProp, warningPlacement, help, warningMessage, helpLive, readOnly: readOnlyProp, readOnlyVariant, id: idProp, allowClear: allowClearProp, ["aria-describedby"]: ariaDescribedByProp, value, defaultValue, placeholder, ...props }: SensTextAreaProps): import("react").JSX.Element;
export type TextAreaPreviewState = "default" | "hover" | "focus" | "disabled" | "disabledHover" | "readOnlyFilled" | "readOnlyPlain";
export interface TextAreaStatesPreviewProps {
    title?: ReactNode;
    filledValue?: string;
}
/** §3.2 变体×状态矩阵：3 变体 × 7 状态 × 2 内容 = 42 格 */
export declare function TextAreaStatesPreview({ title, filledValue, }: TextAreaStatesPreviewProps): import("react").JSX.Element;
