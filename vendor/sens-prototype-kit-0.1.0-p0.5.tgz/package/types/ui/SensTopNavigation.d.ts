import { type CSSProperties } from "react";
import { type IconName } from "../design-system/icons";
import { type TagColor } from "./SensTag";
import "./top-navigation.css";
type FunctionMenuItem = {
    label: string;
    /** Figma 彩色标签：hot→旭日红 / new→冰绽蓝（64:9830） */
    badge?: {
        text: string;
        color: TagColor;
    };
};
export type FunctionMenuSection = {
    /** 有 title → 两层（二级分组 + 三级项）；无 title → 单层 */
    title?: string;
    items: Array<string | FunctionMenuItem>;
};
/** 两层：多二级分区 + 竖分割线；三级 >6 同区内折列（226:29938）；矩阵示意；真实「分析」下拉以 catalog 为准 */
export declare const FUNCTION_MENU_TWO_LEVEL: FunctionMenuSection[];
/** 九宫格产品导航：最近浏览 / 热销产品（Figma 64:9830）；叶子须能映射到一级域下拉 */
export declare const FUNCTION_MENU_NINE_GRID: FunctionMenuSection[];
/** 单层 ≤6：单列（226:30041）；示意叶子对齐智能运营域 */
export declare const FUNCTION_MENU_FLAT_SHORT: FunctionMenuSection[];
/** 单层 >6：自动折列，区间无分割线（226:29988） */
export declare const FUNCTION_MENU_FLAT_WRAP: FunctionMenuSection[];
type FunctionEntryMenuPanelProps = {
    sections: FunctionMenuSection[];
    selectedLabel?: string | null;
    hoveredKey?: string | null;
    onHover?: (key: string | null) => void;
    onSelect?: (label: string) => void;
    onMouseEnter?: () => void;
    onMouseLeave?: () => void;
    textColor: string;
    hoverText: string;
    activeText: string;
    hoverBg: string;
    activeBg: string;
    dividerColor: string;
    style?: CSSProperties;
};
/** 功能入口 / 主导航下拉面板：单层自适应或折列；两层分区竖线；三级每列最多 6 项 */
export declare function FunctionEntryMenuPanel({ sections, selectedLabel, hoveredKey, onHover, onSelect, onMouseEnter, onMouseLeave, textColor, hoverText, activeText, hoverBg, activeBg, dividerColor, style, }: FunctionEntryMenuPanelProps): import("react").JSX.Element;
/** 主导航下拉：flat=单层（≤6 自适应宽 / >6 折列）；grouped=两层分区（Figma 5:2414 分析） */
export type NavDropdownConfig = {
    kind: "flat";
    items: string[];
} | {
    kind: "grouped";
    sections: FunctionMenuSection[];
};
export declare function navDropdownToSections(config: NavDropdownConfig): FunctionMenuSection[];
export interface SensTopNavigationItem {
    label: string;
    arrow?: boolean;
}
export interface SensTopNavigationUtilityItem {
    label: string;
    icon: IconName;
    /** 仅平台、资源、审批等实际功能页入口保留持久选中态。 */
    selectable?: boolean;
}
export interface SensTopNavigationProps {
    /** 业务页面嵌入时只渲染产品壳导航，不渲染组件说明和演示占位内容。 */
    embedded?: boolean;
    /** 是否在导航下方保留产品壳氛围渐变；嵌入页面默认关闭，由业务场景显式开启。 */
    atmosphere?: boolean;
    activeNavLabel?: string;
    items?: SensTopNavigationItem[];
    /**
     * 覆盖 / 合并主导航下拉 IA。Product Shell 应用域导航模型覆盖「智能运营」等与侧导同源的功能域。
     * 未覆盖的 label 仍使用组件内默认配置。
     */
    navDropdownByLabel?: Record<string, NavDropdownConfig>;
    /**
     * 受控：各一级功能域下拉当前选中叶子。与侧导 activeItem 应对齐同一业务节点。
     * 不传时组件内部维护演示态。
     */
    activeNavMenuByLabel?: Record<string, string>;
    /** 主导航下拉选中叶子时回调（含受控与非受控） */
    onNavMenuSelect?: (navLabel: string, menuLabel: string) => void;
    /** 当前所在工具功能页对应的图标（选中态）；不传时由组件内部演示态管理。 */
    activeUtilityIcon?: IconName | null;
    /** 工具入口点击：业务侧跳转功能页。未传时展示页本地切换选中以演示三态。 */
    onUtilityNavigate?: (item: SensTopNavigationUtilityItem) => void;
    /** 主导航业务域选中变化（含无下拉项的一级点击）；Product Shell 用于切换侧导域。 */
    onActiveNavLabelChange?: (navLabel: string) => void;
}
/** 顶部导航的真实实现；展示页与业务样板间共用同一产品壳。 */
export declare function SensTopNavigation({ embedded, atmosphere, activeNavLabel: initialActiveNavLabel, items, navDropdownByLabel, activeNavMenuByLabel: activeNavMenuByLabelProp, onNavMenuSelect, activeUtilityIcon: activeUtilityIconProp, onUtilityNavigate, onActiveNavLabelChange, }: SensTopNavigationProps): import("react").JSX.Element;
export {};
