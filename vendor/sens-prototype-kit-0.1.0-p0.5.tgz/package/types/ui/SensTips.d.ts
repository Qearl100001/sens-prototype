import { type CSSProperties, type ReactElement, type ReactNode } from "react";
import "./tips.css";
export type SensTipsPlacement = "top" | "bottom" | "left" | "right";
/** 箭头在气泡边上的对齐：组成 12 向（上左…右下） */
export type SensTipsAlign = "start" | "center" | "end";
/** 箭头指向深度（Figma 三角 16×6 的短边）；组件契约 */
export declare const SENS_TIPS_ARROW_DEPTH = 6;
/** 箭头横向展开（Figma 三角 16×6 的长边）；组件契约 */
export declare const SENS_TIPS_ARROW_CROSS_SIZE = 16;
/**
 * 边对齐时三角距气泡圆角一侧的空隙（Figma：上下槽 28=6+16+6；左右槽 22=6+16）。
 * 左上/左下/右上/右下均有，避免三角与气泡顶/底连成一体。
 */
export declare const SENS_TIPS_ARROW_EDGE_GAP = 6;
/**
 * 上下边对齐时箭头槽宽（Figma 28 = 6+16+6）；槽贴气泡边，三角在槽内居中 → 尖端距边 14。
 */
export declare const SENS_TIPS_ARROW_EDGE_SLOT_INLINE: number;
/**
 * 左右边对齐时箭头槽高（Figma 22 = 6+16）；三角距角 6 → 尖端距边 14。
 */
export declare const SENS_TIPS_ARROW_EDGE_SLOT_BLOCK: number;
/** 上下边对齐：尖端距气泡边（= 槽宽/2 = 14） */
export declare const SENS_TIPS_ARROW_EDGE_INSET_INLINE: number;
/** 左右边对齐：尖端距气泡边（= 角空隙 6 + 展开/2 = 14） */
export declare const SENS_TIPS_ARROW_EDGE_INSET_BLOCK: number;
/** 便签相对触发源的间距（不含箭头） */
export declare const SENS_TIPS_GAP: number;
/** 便签相对触发源的偏移 = gap + 箭头深度（portal 定位用） */
export declare const SENS_TIPS_OFFSET: number;
/** 悬停出现延迟（ms）；专档 0.1s */
export declare const SENS_TIPS_ENTER_DELAY_MS = 100;
/** 桥接 trigger 与 portal 浮层热区，保证鼠标能进入便签选中文案 */
export declare const SENS_TIPS_LEAVE_GRACE_MS = 80;
/** 浮层层级；组件契约，暂不升全局 z-index token */
export declare const SENS_TIPS_Z_INDEX = 1060;
/** 最大宽度（Figma `6613:32568` / `6613:32687` 外框 300）；不足则随文案变窄 */
export declare const SENS_TIPS_MAX_WIDTH = 300;
/** 触发源宽 ≥ 此值时按前/中/后 1/3 就近对齐（与最大宽同值，组件契约） */
export declare const SENS_TIPS_WIDE_TRIGGER = 300;
/** 自动避让试探顺序（优先于调用方 placement 装不下时） */
export declare const SENS_TIPS_FLIP_ORDER: SensTipsPlacement[];
/** 视口避让边距（px）；贴边时提前换向，组件契约 */
export declare const SENS_TIPS_VIEWPORT_MARGIN = 8;
/** 正文最大行数；超出内滚（10.5 × line-height/m ≈ 231） */
export declare const SENS_TIPS_MAX_LINES = 10.5;
/** 滚动条拇指宽；组件契约（Figma 6） */
export declare const SENS_TIPS_SCROLLBAR_SIZE = 6;
/**
 * Figma `1172:218` 三角 path（viewBox 0 0 16 6，尖朝下）。
 * 软肩曲线；不落 raster 资源，fill 走 currentColor → tooltip-background。
 */
export declare const SENS_TIPS_ARROW_PATH = "M3.46777 1.70906L5.83264 4.93184C6.87773 6.35605 9.12227 6.35606 10.1674 4.93184L12.5322 1.70906C13.3173 0.639184 14.6142 0 16 0H0C1.38576 0 2.6827 0.639182 3.46777 1.70906Z";
export type SensTipsProps = {
    /** 便签正文；常规便签仅纯文案 */
    title: ReactNode;
    /** 触发源；需为单个可承接事件的 React 元素 */
    children: ReactElement;
    placement?: SensTipsPlacement;
    /** 箭头在边上的对齐；默认 center；与 placement 组成 12 向 */
    align?: SensTipsAlign;
    /** 受控显隐；矩阵静态样张用 `open` */
    open?: boolean;
    defaultOpen?: boolean;
    /** 外部场景暂时禁止悬停/聚焦触发，并立即关闭已打开的便签 */
    disabled?: boolean;
    /** 外部交互区域打开时，禁止触发器触发并立即关闭已打开的非受控便签 */
    suppressTriggerOpen?: boolean;
    /** 外部悬停区域（例如 Select 下拉浮层）仍在当前交互范围内 */
    keepOpen?: boolean;
    /** 悬停出现延迟，默认 100ms */
    mouseEnterDelay?: number;
    /**
     * `portal`：挂到 body，fixed 跟随（默认，Demo 悬停用）。
     * `anchored`：相对触发源 absolute（矩阵静态样张用，避免布局变化后跑偏）。
     */
    strategy?: "portal" | "anchored";
    /**
     * 是否自动避让 + 宽触发源分段对齐；默认 true。
     * 仅 `portal` 生效；矩阵 `anchored` 忽略。
     */
    autoAdjust?: boolean;
    className?: string;
    style?: CSSProperties;
};
export declare function buildSensTipsTokenVars(): CSSProperties;
/**
 * 便签 Tips（常规）：深底白字 + 箭头，悬停/聚焦出现。
 * Sens 自持浮层；高级便签不在本组件范围。
 */
export declare function SensTips({ title, children, placement, align, open: openProp, defaultOpen, disabled, suppressTriggerOpen, keepOpen, mouseEnterDelay, strategy, autoAdjust, className, style, }: SensTipsProps): import("react").JSX.Element;
/** 状态矩阵：12 向静态展开（受控 open + anchored，避免文档栏布局变化后跑偏） */
export declare function TipsStatesPreview(): import("react").JSX.Element;
