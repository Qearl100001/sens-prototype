import { type ReactNode } from "react";
import { type ButtonProps, type DropdownProps } from "antd";
import { type SensDropdownMenuItemConfig } from "./SensDropdownMenuItem";
/** 常规无图标两字插空格；链接类 / 有图标保持紧凑。与 SensButton 同规则。 */
export declare function formatButtonText(content: ReactNode, options: {
    tone: SensButtonVariant;
    hasIcon: boolean;
    noSpaceWords?: ReadonlySet<string>;
}): ReactNode;
export type SensButtonVariant = "primary" | "secondary" | "tertiary" | "link" | "linkWeak" | "dangerSecondary" | "dangerSecondaryWeak" | "dangerTertiary" | "dangerTertiaryWeak" | "dangerLink" | "dangerLinkEmphasis" | "dangerLinkWeak" | "dashed";
export type ButtonPreviewState = "default" | "hover" | "active" | "disabled" | "disabledHover" | "loading" | "loadingHover";
/** 下拉按钮核心 4 态（Figma 1257:3688 / 3712 / 3722 / 1264:2830） */
export type DropdownButtonPreviewState = "default" | "hover" | "active" | "open";
export type SensButtonRef = HTMLButtonElement | HTMLAnchorElement;
export interface SensButtonProps extends Omit<ButtonProps, "type" | "variant"> {
    tone?: SensButtonVariant;
    /** 横向单项 FAB：与 tone=primary|secondary 组合；圆角 999、恒 D4 投影、二级无描边白底 */
    fab?: boolean;
}
/** 按钮语义封装：仅通过 antd props + 主题 token 驱动样式。 */
export declare const SensButton: import("react").ForwardRefExoticComponent<SensButtonProps & import("react").RefAttributes<SensButtonRef>>;
export type SensMoreButtonTone = Extract<SensButtonVariant, "primary" | "secondary" | "tertiary">;
export interface SensMoreButtonProps extends Omit<SensButtonProps, "tone" | "icon" | "iconPosition"> {
    /** 与同级别主/次/三级按钮一致；矩阵默认 secondary */
    tone?: SensMoreButtonTone;
}
/** 更多 ··· 按钮（Figma 矩阵「更多 / 大尺寸」；二级 + 横向省略号尾图标） */
export declare const SensMoreButton: import("react").ForwardRefExoticComponent<SensMoreButtonProps & import("react").RefAttributes<SensButtonRef>>;
export type { SensDropdownMenuItemConfig } from "./SensDropdownMenuItem";
export interface SensDropdownButtonProps extends Omit<ButtonProps, "type" | "variant" | "color" | "icon" | "iconPosition"> {
    items: SensDropdownMenuItemConfig[];
    dropdownProps?: Omit<DropdownProps, "menu" | "children" | "dropdownRender" | "popupRender">;
}
/** 下拉链接按钮：收起 ▼，展开 ▲（Figma 1257:3688–3722 / 1264:2830）；默认 click 展开，非 antd hover */
export declare function SensDropdownButton({ children, items, dropdownProps, className, loading, disabled, style, ...rest }: SensDropdownButtonProps): import("react").JSX.Element;
export interface ButtonStatesPreviewProps {
    title?: ReactNode;
    /** 插在「横向单项 FAB」与「下拉」之间的预览区（如组合 FAB） */
    afterFabSection?: ReactNode;
}
export declare function ButtonStatesPreview({ title, afterFabSection }: ButtonStatesPreviewProps): import("react").JSX.Element;
