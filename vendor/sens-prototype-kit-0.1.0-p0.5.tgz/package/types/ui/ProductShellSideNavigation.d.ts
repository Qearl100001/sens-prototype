import { type IconName, type IconVariant } from "../design-system/icons";
import "./side-navigation.css";
/** Figma 1777:111120 · 产品壳侧导航紧凑态固定宽度。 */
export declare const PRODUCT_SHELL_SIDE_NAV_COLLAPSED_WIDTH = 30;
/** Figma 18593:101946 · 单层带图标侧导航紧凑态固定宽度。 */
export declare const PRODUCT_SHELL_SIDE_NAV_ICON_COLLAPSED_WIDTH = 56;
/** Figma 1777:111114 · 产品壳侧导航展开态固定宽度。 */
export declare const PRODUCT_SHELL_SIDE_NAV_EXPANDED_WIDTH = 220;
export type ProductShellSideNavigationMode = "normal" | "overlay" | "docked";
export interface ProductShellSideNavigationGroup {
    key: string;
    label: string;
    /** 二级虚拟分组图标；传入后进入「二级有图标 / 三级无图标」侧导场景。 */
    icon?: IconName;
    iconVariant?: IconVariant;
    /** 字符串项用于三级无图标场景；对象项用于「分析专属」二级落地功能带图标场景。 */
    items: Array<string | ProductShellSideNavigationItem>;
    defaultExpanded?: boolean;
    recommended?: boolean;
}
export interface ProductShellSideNavigationItem {
    key: string;
    label: string;
    icon?: IconName;
    iconVariant?: IconVariant;
}
export interface ProductShellSideNavigationProps {
    mode?: ProductShellSideNavigationMode;
    onModeChange?: (mode: ProductShellSideNavigationMode) => void;
    productName?: string;
    /** 无层级的页面目录；传入后不渲染分组标题和展开控件。带 icon 时进入「单层带图标」侧导场景。 */
    items?: Array<string | ProductShellSideNavigationItem>;
    groups?: ProductShellSideNavigationGroup[];
    activeItem?: string;
    onActiveItemChange?: (item: string) => void;
    /**
     * 分组是否可收起。false 时全部展开且不展示开合箭头（样板间产品壳默认）。
     * 默认 true，保留 showcase 等可收起演示。
     */
    groupsCollapsible?: boolean;
}
/**
 * 产品壳专属侧导航。它负责产品模块和菜单层级，不负责页面内锚点、目录等 Context Side Panel。
 */
export declare function ProductShellSideNavigation({ mode: controlledMode, onModeChange, productName, items, groups, activeItem: controlledActiveItem, onActiveItemChange, groupsCollapsible, }: ProductShellSideNavigationProps): import("react").JSX.Element;
