import type { CSSProperties, ReactNode } from "react";
import "./dropdown-menu.css";
import "./dropdown-menu-preview.css";
/** Figma 链接菜单面板：8×34 + 上6 + 下10 = 288 */
export declare const DROPDOWN_MENU_ITEM_HEIGHT = 34;
export declare const DROPDOWN_MENU_MATRIX_CELL_WIDTH = 160;
/**
 * 动作菜单浮层 CSS 变量（portaled overlay 须经 overlayStyle / SensDropdownMenu style 注入）。
 * SensDropdownButton 会把本 hook 返回值挂到 `.sens-dropdown-menu-overlay` portal 根。
 * M1/M2：未来 components.Menu token 或共享 PopupShell 只改此 hook + dropdown-menu.css 变量名。
 */
export declare function useSensDropdownMenuStyle(): CSSProperties;
export interface SensDropdownMenuProps {
    children: ReactNode;
    className?: string;
    style?: CSSProperties;
}
export declare function SensDropdownMenu({ children, className, style }: SensDropdownMenuProps): import("react").JSX.Element;
export interface DropdownMenuStatesPreviewProps {
    title?: ReactNode;
}
/** 3 variant × 7 态 = 21 格（对齐 Select R1 态列 + 加载） */
export declare function DropdownMenuStatesPreview({ title }: DropdownMenuStatesPreviewProps): import("react").JSX.Element;
