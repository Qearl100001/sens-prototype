import type { CSSProperties, HTMLAttributes, ReactNode } from "react";
import "./section-title.css";
export type SensSectionTitleVariant = "general" | "productLine";
export type SensSectionTitleSize = "large" | "small";
export interface SensSectionTitleProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
    title?: ReactNode;
    children?: ReactNode;
    variant?: SensSectionTitleVariant;
    size?: SensSectionTitleSize;
    /** 辅助说明文案，与标题同一行、基线对齐 */
    description?: ReactNode;
    /** 选填文案，如 `(选填)` */
    optional?: ReactNode;
    /**
     * 帮助 Tips 内容。有值时渲染帮助 icon，hover / focus 出 Tips。
     * 自定义图标仍可通过 `helpIcon` 槽位覆盖。
     */
    help?: ReactNode;
    /** 帮助图标槽位；未传且有 `help` 时默认 `SensIcon name="help"` */
    helpIcon?: ReactNode;
    /** 右侧操作区；仅 `general` + `large` 展示 */
    actions?: ReactNode;
}
/** Preview / Demo 容器也可挂同一套 CSS 变量（gap 等写在父级，不能指望子标题继承上来） */
export declare function buildSectionTitleTokenVars(): CSSProperties;
export declare function SensSectionTitle({ title, children, variant, size, description, optional, help, helpIcon, actions, className, style, ...rootProps }: SensSectionTitleProps): import("react").JSX.Element;
