import type { InputProps } from "antd";
export interface UseMinimalSearchValueOptions {
    value?: InputProps["value"];
    defaultValue?: InputProps["defaultValue"];
    onChange?: InputProps["onChange"];
    onBack?: () => void;
}
export interface UseMinimalSearchValueResult {
    value: string;
    setValue: (next: string) => void;
    hasValue: boolean;
    resetValue: () => void;
    handleChange: InputProps["onChange"];
}
/** 简约搜索受控/非受控值 + 返回清空（对齐 useSelectDropdownSearch.resetSearch） */
export declare function useMinimalSearchValue({ value: valueProp, defaultValue, onChange, onBack, }: UseMinimalSearchValueOptions): UseMinimalSearchValueResult;
