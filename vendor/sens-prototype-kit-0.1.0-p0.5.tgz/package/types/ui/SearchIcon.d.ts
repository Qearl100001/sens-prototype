import type { CSSProperties } from "react";
export interface SearchIconProps {
    size?: number;
    className?: string;
    style?: CSSProperties;
    /** 默认 currentColor，由父级或 style.color 控制 */
    color?: string;
}
/** Figma 803:171 · 设计系统搜索图标（16×16） */
export declare function SearchIcon({ size, className, style, color, }: SearchIconProps): import("react").JSX.Element;
