import type { CSSProperties, ReactNode } from "react";
import { type NonPageEmptySize, type NonPageEmptyType, type PageEmptySize, type PageEmptyType } from "./EmptyStateIllustrations";
import "./empty-state.css";
/** 页面级插画→文案间距；等同 `spacing/vertical/8x`（32） */
export declare const EMPTY_STATE_PAGE_STACK_GAP: number;
/** 页面级大插画边长（Figma 266） */
export declare const EMPTY_STATE_PAGE_ILLUSTRATION_LARGE = 266;
/** 页面级小插画边长（Figma 192） */
export declare const EMPTY_STATE_PAGE_ILLUSTRATION_SMALL = 192;
/** 非页面级基础插画边长（Figma 100） */
export declare const EMPTY_STATE_NON_PAGE_ILLUSTRATION_BASE = 100;
/** 非页面级特殊插画边长（Figma 50） */
export declare const EMPTY_STATE_NON_PAGE_ILLUSTRATION_SPECIAL = 50;
export type SensEmptyStatePageProps = {
    scope: "page";
    type: PageEmptyType;
    size?: PageEmptySize;
};
export type SensEmptyStateNonPageProps = {
    scope: "non-page";
    type: NonPageEmptyType;
    size?: NonPageEmptySize;
};
export type SensEmptyStateProps = (SensEmptyStatePageProps | SensEmptyStateNonPageProps) & {
    title?: ReactNode;
    /**
     * 完整自定义说明。传入后不再拼默认前缀 / 后缀 / 内嵌链接；
     * 需要链接时自行放进节点，或改用 `descriptionPrefix` + `actionLabel`。
     */
    description?: ReactNode;
    /** 覆盖默认说明前缀（与 actionLabel / descriptionSuffix 组合） */
    descriptionPrefix?: string;
    /** 内嵌链接文案；未传 description 时与前缀组合 */
    actionLabel?: string;
    onAction?: () => void;
    /** 标题下方额外操作区（如主按钮），与内嵌链接互不冲突 */
    actions?: ReactNode;
    illustrationSrc?: string;
    className?: string;
    style?: CSSProperties;
};
/**
 * 异常状态 / 空态：页面级与非页面级插画 + 标题 + 说明（可内嵌链接）。
 * 资产来自 `EmptyStateIllustrations`；不进入 Icon registry。
 */
export declare function SensEmptyState(props: SensEmptyStateProps): import("react").JSX.Element;
