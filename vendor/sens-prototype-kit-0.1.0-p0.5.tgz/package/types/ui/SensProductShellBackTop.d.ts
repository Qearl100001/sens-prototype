import { type RefObject } from "react";
export interface SensProductShellBackTopProps {
    visible: boolean;
    docked: boolean;
    anchorRef: RefObject<HTMLElement | null>;
    onBackToTop: () => void;
    onPointerEnter: () => void;
    onPointerLeave: () => void;
}
export declare function SensProductShellBackTop({ visible, docked, anchorRef, onBackToTop, onPointerEnter, onPointerLeave, }: SensProductShellBackTopProps): import("react").JSX.Element | null;
