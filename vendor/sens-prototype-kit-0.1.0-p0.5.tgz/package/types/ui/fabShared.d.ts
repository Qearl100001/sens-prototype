import type { CSSProperties, ReactNode } from "react";
import type { ButtonProps } from "antd";
declare const c: Record<string, string>;
declare const u: Record<string, number>;
export declare const FAB_RADIUS_PX: number;
export declare const FAB_RADIUS: string;
/** FAB 交叉轴高度：size/component-height/l（常规 Button 仍用 m=32） */
export declare const FAB_COMPONENT_HEIGHT_PX: number;
export declare const FAB_COMPONENT_HEIGHT: string;
export declare const FAB_GROUP_PADDING_OUTER: number;
export declare const FAB_GROUP_PADDING_INNER: number;
export declare const FAB_SEGMENT_ICON_GAP: number;
/** 竖向组合段内图标：size/icon/m（Figma 16×16） */
export declare const FAB_ICON_SIZE_PX: number;
export declare const FAB_ICON_SIZE: string;
/** 单项 FAB 文字/图文横向 padding；与 spacing/horizontal/5x 同源，仅作用于 sens-btn-fab（非组合分段） */
export declare const FAB_SINGLE_PADDING_HORIZONTAL: number;
export type FabTone = "primary" | "secondary";
export type FabPreviewState = "default" | "hover" | "active" | "disabled" | "disabledHover" | "loading" | "loadingHover";
export type FabGroupDirection = "horizontal" | "vertical";
export type FabGroupSegmentPosition = "first" | "mid" | "last";
export interface FabStyleToken {
    primary: string;
    primaryHover: string;
    primaryActive: string;
    bgContainer: string;
    disabledBg: string;
    disabledBorder: string;
    disabledText: string;
    disabledHoverBg: string;
    disabledHoverBorder: string;
    disabledHoverText: string;
}
export interface ButtonShadowToken {
    hover: string;
    floating: string;
}
export declare function getButtonShadowToken(): ButtonShadowToken;
export declare function isFabTone(tone: string): tone is FabTone;
/** 单项 FAB：带 sens-btn-fab class */
export declare function buildFabToneProps(tone: FabTone): ButtonProps;
export declare function getFabGroupSegmentPosition(index: number, count: number): FabGroupSegmentPosition;
export declare function getFabGroupSegmentBorderRadius(direction: FabGroupDirection, index: number, count: number): string;
export interface FabGroupSegmentPaddingHorizontal {
    paddingLeft: number;
    paddingRight: number;
}
export interface FabGroupSegmentPaddingVertical {
    paddingTop: number;
    paddingBottom: number;
    paddingLeft: number;
    paddingRight: number;
}
/**
 * 横向组合分段 padding：使用 `paddingInline` 表达左右分段规则。
 * 竖向走 top/bottom/left/right。
 * icon-only 与文字/图文共用外20/内10 分段规则（`isFabIconOnly` 仅用于识别形态，不改 padding 数值）。
 */
export declare function getFabGroupSegmentPaddingStyle(direction: FabGroupDirection, index: number, count: number, content?: ReactNode, icon?: ReactNode, loading?: boolean): CSSProperties;
export declare function getFabGroupSegmentPadding(direction: FabGroupDirection, index: number, count: number): FabGroupSegmentPaddingHorizontal | FabGroupSegmentPaddingVertical;
export declare function isFabIconOnly(content: ReactNode, icon: ReactNode | undefined, loading: boolean): boolean;
export declare function resolveFabShape(content: ReactNode, icon: ReactNode | undefined, loading: boolean): NonNullable<ButtonProps["shape"]>;
export declare function getFabRadiusStyle(): CSSProperties;
/** 一级 FAB 无描边：inline 压 antd css-in-js，保留 1px border-width 盒模型 */
export declare function getFabPrimaryBorderStyle(): CSSProperties;
/** 注入 FAB 高度/图标尺寸 CSS 变量 */
export declare function getFabCssVars(): CSSProperties;
/** 单项/组合 FAB 交叉轴：文字图文 height=l；纯图标 circle 为 l×l、padding 0 */
export declare function getFabCrossAxisStyle(content: ReactNode, icon: ReactNode | undefined, loading: boolean): CSSProperties;
/** 横向组合 FAB 分段固定交叉轴高度；纯图标段通过 padding 20/10 撑开宽度。 */
export declare function getFabGroupSegmentCrossAxisStyle(direction?: FabGroupDirection, content?: ReactNode, icon?: ReactNode, loading?: boolean): CSSProperties;
/** 单项 FAB 文字/图文：左右各 spacing/horizontal/5x；纯图标 circle 不设 padding（走 l×l） */
export declare function getFabSinglePaddingStyle(content: ReactNode, icon: ReactNode | undefined, loading: boolean): CSSProperties;
export declare function getFabSecondaryCssVars(): CSSProperties;
/** 竖向组合 FAB：图标色阶独立（不走横向二级 text-color / component-hover） */
export declare function getFabVerticalIconCssVars(): CSSProperties;
export type FabVerticalPreviewState = "default" | "hover" | "active";
export declare const FAB_VERTICAL_PREVIEW_ICON_COLOR: Record<FabVerticalPreviewState, string>;
export declare function getFabVerticalIconColor(isHovered: boolean, isPressed: boolean): string;
export declare function getFabVerticalGroupSegmentBaseStyle(index: number, count: number): CSSProperties;
export declare function getFabVerticalGroupSegmentPreviewStyle(state: FabVerticalPreviewState, index: number, count: number): CSSProperties;
export declare function getFabDefaultSnapshotStyle(tone: FabTone, t: FabStyleToken): CSSProperties;
export declare function getFabHoverSnapshotStyle(tone: FabTone, t: FabStyleToken): CSSProperties;
export declare function getFabActiveSnapshotStyle(tone: FabTone, t: FabStyleToken): CSSProperties;
export declare function getFabDisabledSnapshotStyle(tone: FabTone, t: FabStyleToken): CSSProperties;
export declare const FAB_PREVIEW_STATE_COLOR: Partial<Record<FabPreviewState, string>>;
export declare function getFabSnapshotStyleForState(tone: FabTone, state: FabPreviewState, t: FabStyleToken): CSSProperties;
export declare function getFabGroupSegmentPreviewStyle(tone: FabTone, state: FabPreviewState, index: number, count: number, t: FabStyleToken, content?: ReactNode, icon?: ReactNode, loading?: boolean): CSSProperties;
export declare function getFabSinglePreviewStyle(tone: FabTone, state: FabPreviewState, t: FabStyleToken, shadowToken: ButtonShadowToken): CSSProperties;
export interface FabPreviewCellSnapshot {
    buttonProps: ButtonProps;
    style?: CSSProperties;
    icon?: ReactNode;
}
export declare function buildFabPreviewCellSnapshot(tone: FabTone, state: FabPreviewState, styleToken: FabStyleToken, shadowToken: ButtonShadowToken): FabPreviewCellSnapshot;
export { c as fabColorTokens, u as fabUnitTokens };
