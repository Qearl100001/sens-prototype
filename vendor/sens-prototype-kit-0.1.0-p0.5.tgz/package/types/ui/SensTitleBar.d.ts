import type { CSSProperties, ReactNode } from "react";
export declare const SENS_TITLE_BAR_HEIGHT: number;
export declare const SENS_TITLE_BAR_BACK_HIT_SIZE: number;
export interface SensTitleBarProps {
    title: ReactNode;
    actions?: ReactNode;
    onBack?: () => void;
    className?: string;
    style?: CSSProperties;
    titleStyle?: CSSProperties;
    /** 供抽屉等 dialog 挂 `aria-labelledby`；由 SensDrawer 注入时可省略 */
    titleId?: string;
}
/** 标题栏 / 面包屑场景的标题区：背景跟随导航换肤 token。 */
export declare function SensTitleBar({ title, actions, onBack, className, style, titleStyle, titleId, }: SensTitleBarProps): import("react").JSX.Element;
