import { type CSSProperties, type ReactNode } from "react";
/** 轻提示 / 警告共用 type（Alert 不含 loading） */
export type FeedbackTone = "default" | "success" | "info" | "warning";
export type MessageType = FeedbackTone | "loading";
export type AlertType = FeedbackTone;
export declare const MESSAGE_TYPE_LABEL: Record<MessageType, string>;
export declare const ALERT_TYPE_LABEL: Record<AlertType, string>;
/** 有辅助文案时上下 pad = (单行高度 − 标题行高) / 2；不新增 5/7 spacing 档 */
export declare function feedbackDerivedPadBlock(componentHeight: number, titleLineHeight: number): number;
export declare function feedbackLayoutTokens(): {
    iconSize: number;
    fontSize: number;
    lineHeight: number;
    /** Figma 4212:16045 · 中文/辅助信息 12/18 */
    descriptionFontSize: number;
    descriptionLineHeight: number;
    /** 标题↔辅助 gap · Figma 4 */
    descriptionGap: number;
    radius: number;
    padInline: number;
    gap: number;
    messageTextToLinkGap: number;
    /** 轻提示单行整体高 32 */
    messageHeight: number;
    /** 警告单行整体高 36；有辅助时不锁高，复用由此推导的 pad */
    alertHeight: number;
    alertPadBlockWithDescription: number;
};
export declare function resolveFeedbackIconColor(type: MessageType): string;
export declare function resolveAlertSurface(type: AlertType): {
    background: string;
    borderColor: string;
};
export declare function feedbackTitleColor(): string;
export declare function feedbackDescriptionColor(): string;
export type FeedbackCloseState = "default" | "hover" | "active";
export declare function feedbackCloseColor(state?: FeedbackCloseState): string;
export declare function FeedbackStatusIcon({ type, color, size, }: {
    type: MessageType;
    color: string;
    size: number;
}): import("react").JSX.Element;
/** 轻提示：整体高 `size/component-height/m`（32），内容垂直居中 */
export declare function messageContainerStyle(): CSSProperties;
/** 警告：单行锁 `size/component-height/l`（36）；有辅助文案 hug + 公式 pad */
export declare function alertContainerStyle(type: AlertType, options?: {
    withDescription?: boolean;
}): CSSProperties;
export declare function feedbackTextBlockStyle(options?: {
    description?: boolean;
}): CSSProperties;
export type FeedbackCloseButtonProps = {
    onClose?: () => void;
    label?: string;
};
export declare function FeedbackCloseButton({ onClose, label, alignWithTitleRow, }: FeedbackCloseButtonProps & {
    alignWithTitleRow?: boolean;
}): import("react").JSX.Element;
export declare function FeedbackLinkSlot({ children, alignWithTitleRow, }: {
    children?: ReactNode;
    /** 有辅助文案时与标题行顶对齐（链接高 = line-height/m，无需再偏移） */
    alignWithTitleRow?: boolean;
}): import("react").JSX.Element | null;
