import type { DefaultOptionType } from "antd/es/select";
export type SelectOptionFilterMatcher = (label: string, query: string, searchText?: string) => boolean;
/** 业务可选：多音字 / 专有名词搜索兜底 */
export type SensSelectDropdownOption = DefaultOptionType & {
    searchText?: string;
};
export interface OptionSearchKeys {
    labelLower: string;
    fullPinyin: string;
    initials: string;
    searchTextLower?: string;
    searchTextFullPinyin?: string;
    searchTextInitials?: string;
}
export declare function normalizeSelectQuery(query: string): string;
export declare function buildOptionSearchKeys(label: string, searchText?: string): OptionSearchKeys;
export declare function getOptionSearchText(option: DefaultOptionType): string | undefined;
export declare function getOptionLabel(option: DefaultOptionType): string;
export declare function matchSelectOptionByKeys(keys: OptionSearchKeys, query: string): boolean;
export declare function defaultSelectOptionMatcher(label: string, query: string, searchText?: string): boolean;
export interface OptionSearchIndexEntry {
    option: DefaultOptionType;
    label: string;
    searchText?: string;
    keys: OptionSearchKeys;
}
export declare function isSelectOptionGroup(option: DefaultOptionType): boolean;
export declare function flattenSelectOptions(options: DefaultOptionType[]): DefaultOptionType[];
export declare function countSelectOptions(options: DefaultOptionType[] | undefined): number;
export declare function hasSelectOptionGroups(options: DefaultOptionType[] | undefined): boolean;
export declare function buildOptionSearchIndex(options: DefaultOptionType[]): OptionSearchIndexEntry[];
