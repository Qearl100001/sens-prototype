import type { HTMLAttributes, InputHTMLAttributes, ReactNode } from "react";
import "./radio.css";
export interface SensRadioProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "children" | "type"> {
    /**
     * Visible label content. When omitted, provide aria-label or aria-labelledby
     * so the native radio still has an accessible name.
     */
    children?: ReactNode;
    description?: ReactNode;
    icon?: ReactNode;
    helpIcon?: ReactNode;
}
export declare function SensRadio({ className, style, children, description, icon, helpIcon, disabled, readOnly, checked, defaultChecked, onClick, onChange, ...inputProps }: SensRadioProps): import("react").JSX.Element;
export interface SensRadioGroupOption {
    value: string;
    label: ReactNode;
    description?: ReactNode;
    disabled?: boolean;
    readOnly?: boolean;
    icon?: ReactNode;
    helpIcon?: ReactNode;
}
export interface SensRadioGroupProps extends Omit<HTMLAttributes<HTMLDivElement>, "defaultValue" | "onChange"> {
    options: SensRadioGroupOption[];
    value?: string;
    defaultValue?: string;
    name?: string;
    disabled?: boolean;
    readOnly?: boolean;
    direction?: "horizontal" | "vertical";
    /** Use natural option height when the group directly controls linked content. */
    itemHeight?: "control" | "content";
    onChange?: (value: string) => void;
}
export declare function SensRadioGroup({ options, value, defaultValue, name, disabled, readOnly, direction, itemHeight, className, style, onChange, ...rootProps }: SensRadioGroupProps): import("react").JSX.Element;
export type RadioPreviewState = "default" | "hover" | "active" | "disabled" | "disabledHover";
export type RadioPreviewValue = "unchecked" | "checked";
export declare function RadioStatesPreview(): import("react").JSX.Element;
