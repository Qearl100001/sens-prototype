import type { HTMLAttributes, InputHTMLAttributes, ReactNode } from "react";
import "./checkbox.css";
export interface SensCheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "children" | "type"> {
    /**
     * Visible label content. When omitted, provide aria-label or aria-labelledby
     * so the native checkbox still has an accessible name.
     */
    children?: ReactNode;
    description?: ReactNode;
    icon?: ReactNode;
    helpIcon?: ReactNode;
    indeterminate?: boolean;
}
export declare function SensCheckbox({ className, style, children, description, icon, helpIcon, indeterminate, disabled, readOnly, checked, defaultChecked, onClick, onChange, ...inputProps }: SensCheckboxProps): import("react").JSX.Element;
export interface SensCheckboxGroupOption {
    value: string;
    label: ReactNode;
    description?: ReactNode;
    disabled?: boolean;
    readOnly?: boolean;
    icon?: ReactNode;
    helpIcon?: ReactNode;
    indeterminate?: boolean;
}
export interface SensCheckboxGroupProps extends Omit<HTMLAttributes<HTMLDivElement>, "defaultValue" | "onChange"> {
    options: SensCheckboxGroupOption[];
    value?: string[];
    defaultValue?: string[];
    name?: string;
    disabled?: boolean;
    readOnly?: boolean;
    direction?: "horizontal" | "vertical";
    /** Use natural option height when the group directly controls linked content. */
    itemHeight?: "control" | "content";
    onChange?: (value: string[]) => void;
}
export declare function SensCheckboxGroup({ options, value, defaultValue, name, disabled, readOnly, direction, itemHeight, className, style, onChange, ...rootProps }: SensCheckboxGroupProps): import("react").JSX.Element;
export type CheckboxPreviewState = "default" | "hover" | "active" | "disabled" | "disabledHover";
export type CheckboxPreviewValue = "unchecked" | "checked" | "indeterminate";
export declare function CheckboxStatesPreview(): import("react").JSX.Element;
