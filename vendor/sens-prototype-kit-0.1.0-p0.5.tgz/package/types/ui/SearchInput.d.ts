import { type InputProps, type SelectProps } from "antd";
import type { SearchProps } from "antd/es/input";
import "./search.css";
import "./select-dropdown.css";
export declare const SEARCH_INPUT_DEFAULT_WIDTH = 200;
/** @deprecated 不再作为组件总宽；仅预览矩阵列宽估算（分类自适应 + 搜索 200px） */
export declare const SEARCH_CATEGORY_DEFAULT_WIDTH = 280;
export declare const SEARCH_TRIGGER_CATEGORY_PREVIEW_WIDTH = 312;
export declare const SEARCH_CATEGORY_MINIMAL_WIDTH = 272;
/** 布局估算宽（简约+创建）；尚无 spacing token，勿升 foundation */
export declare const SEARCH_MINIMAL_CREATE_DEFAULT_WIDTH = 253;
export type SearchVisualVariant = "default" | "minimal";
export type SearchPreviewState = "default" | "hover" | "focus" | "filled";
/** Figma 1601:10979 · 简约搜索预览态 */
export type MinimalSearchPreviewState = "default" | "hoverSearch" | "clickSearch" | "activeSearch" | "hoverSelector" | "clickSelector" | "activeSelector";
export interface SearchInputProps extends Omit<InputProps, "prefix" | "allowClear" | "variant" | "size" | "disabled"> {
    /** 定宽，默认 200px（规范 108–600px） */
    width?: number;
    /** 常规（描边）或简约（仅底部分割线）；均为 32px 高，无 small 尺寸 */
    visualVariant?: SearchVisualVariant;
    /** 简约：点返回清空后回调 */
    onBack?: () => void;
}
/** 实时型搜索：前缀图标 + allowClear，无搜索按钮（search.md）；搜索无禁用态 */
export declare function SearchInput({ width, visualVariant, style, className, placeholder, onBack, value, defaultValue, onChange, ...rest }: SearchInputProps): import("react").JSX.Element;
export interface CategorySearchInputProps extends Omit<InputProps, "prefix" | "allowClear" | "variant" | "size" | "disabled"> {
    searchWidth?: number;
    visualVariant?: SearchVisualVariant;
    categoryOptions?: SelectProps["options"];
    categoryValue?: string;
    defaultCategoryValue?: string;
    onCategoryChange?: (value: string) => void;
    onBack?: () => void;
    /** 预览板：强制分类 Select 展开（激活选择器） */
    categorySelectOpen?: boolean;
}
/** 实时型 + 左侧分类选择：Select(分类) + Input(搜索) 左右相接 */
export declare function CategorySearchInput({ searchWidth, visualVariant, categoryOptions, categoryValue, defaultCategoryValue, onCategoryChange, style, className, placeholder, onBack, categorySelectOpen, value, defaultValue, onChange, ...rest }: CategorySearchInputProps): import("react").JSX.Element;
export interface SearchTriggerInputProps extends Omit<InputProps, "addonAfter" | "size" | "disabled"> {
    width?: number;
    onSearch?: SearchProps["onSearch"];
}
/** 触发型搜索：Input.Search，点击按钮 / 回车触发；搜索无禁用态 */
export declare function SearchTriggerInput({ width, style, placeholder, value, defaultValue, onChange, onSearch, ...rest }: SearchTriggerInputProps): import("react").JSX.Element;
export interface CategorySearchTriggerInputProps extends SearchTriggerInputProps {
    searchWidth?: number;
    categoryOptions?: SelectProps["options"];
    categoryValue?: string;
    defaultCategoryValue?: string;
    onCategoryChange?: (value: string) => void;
}
/** 触发型 + 左侧分类选择；搜索无禁用态 */
export declare function CategorySearchTriggerInput({ searchWidth, categoryOptions, categoryValue, defaultCategoryValue, onCategoryChange, style, className, placeholder, value, defaultValue, onChange, ...rest }: CategorySearchTriggerInputProps): import("react").JSX.Element;
export interface MinimalSearchWithCreateProps extends SearchInputProps {
    /** 是否显示右侧「创建」；默认 true */
    showCreate?: boolean;
    createLabel?: string;
    onCreate?: () => void;
    createDisabled?: boolean;
}
/** 简约实时搜索 + 可选右侧文字按钮「创建」 */
export declare function MinimalSearchWithCreate({ width, showCreate, createLabel, onCreate, createDisabled, className, style, onBack, ...rest }: MinimalSearchWithCreateProps): import("react").JSX.Element;
export interface SearchStatesPreviewProps {
    filledValue?: string;
}
/** Figma 813:276 / 2216:10655 变体×状态矩阵 */
export declare function SearchStatesPreview({ filledValue }: SearchStatesPreviewProps): import("react").JSX.Element;
export { useSearchTokens, useSearchRootStyle } from "./searchTokens";
