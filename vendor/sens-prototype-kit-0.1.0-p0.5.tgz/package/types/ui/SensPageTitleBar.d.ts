import type { CSSProperties, ReactNode } from "react";
import { type SensBreadcrumbItem } from "./SensBreadcrumb";
export declare const SENS_PAGE_TITLE_BAR_HEIGHT: number;
type SensPageTitleBarVariant = "landing" | "drilldown";
export interface SensPageTitleBarProps {
    /** landing 用于落地页白底标题区；drilldown 用于带面包屑/返回的浅灰标题区。 */
    variant?: SensPageTitleBarVariant;
    title: ReactNode;
    description?: ReactNode;
    breadcrumbItems?: SensBreadcrumbItem[];
    breadcrumbEllipsis?: boolean;
    actions?: ReactNode;
    onBack?: () => void;
    className?: string;
    style?: CSSProperties;
    /** 可选；挂在标题节点，便于页面级 heading / 测试定位 */
    titleId?: string;
}
/** 页面标题栏：不包含顶部导航，只承载返回、面包屑、页面标题和右侧操作。 */
export declare function SensPageTitleBar({ variant, title, description, breadcrumbItems, breadcrumbEllipsis, actions, onBack, className, style, titleId, }: SensPageTitleBarProps): import("react").JSX.Element;
export {};
