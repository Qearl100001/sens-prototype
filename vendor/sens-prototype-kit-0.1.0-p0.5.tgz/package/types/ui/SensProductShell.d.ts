import type { HTMLAttributes, ReactNode } from "react";
import { type ProductShellSideNavigationMode } from "./ProductShellSideNavigation";
import "./sens-product-shell.css";
export type SensProductShellLayout = "t" | "vertical";
export interface SensProductShellProps extends Omit<HTMLAttributes<HTMLElement>, "title"> {
    layout?: SensProductShellLayout;
    topNavigation: ReactNode;
    titleBar: ReactNode;
    sideNavigation?: ReactNode;
    sideNavigationMode?: ProductShellSideNavigationMode;
    collapsedSideWidth?: number;
    contentLabel: string;
    scrollClassName?: string;
    children: ReactNode;
}
export declare function SensProductShell({ layout, topNavigation, titleBar, sideNavigation, sideNavigationMode, collapsedSideWidth, contentLabel, scrollClassName, children, className, style, ...rest }: SensProductShellProps): import("react").JSX.Element;
