import { type ReactElement, type ReactNode } from "react";
/**
 * 占位符过长截断时展示全文（search.md）。
 * 一律 `SensTips`（含 Space.Compact 带分类）；有输入后不展示 tip。
 */
export declare function SearchPlaceholderTip({ placeholder, hasValue, disabled, children, }: {
    placeholder: string;
    hasValue: boolean;
    disabled?: boolean;
    children: ReactElement;
}): ReactNode;
