import { type CSSProperties, type ReactNode } from "react";
export type SensDrawerSize = "small" | "medium" | "large";
/**
 * 1440 基宽对照值（Figma 30% / 60% / 80%）。
 * 运行时宽度为比例动态：`clamp(min@1440, Nvw, max@1920)`。
 * 比例动态宽属布局机制，不进 semantic-unit 生成链路；本常量为组件契约 Ready。
 */
export declare const SENS_DRAWER_WIDTH: Record<SensDrawerSize, number>;
/** Figma 宽度系数；视口介于 1440～1920 时随屏宽变化 */
export declare const SENS_DRAWER_WIDTH_RATIO: Record<SensDrawerSize, number>;
/** 宽度 clamp 视口下界 / 上界（px） */
export declare const SENS_DRAWER_VIEWPORT_MIN = 1440;
export declare const SENS_DRAWER_VIEWPORT_MAX = 1920;
/** 抽屉浮层层级（组件契约；暂不升全局 z-index token） */
export declare const SENS_DRAWER_Z_INDEX = 1000;
/** 开合动效时长（ms）；组件契约，暂不升 motion token */
export declare const SENS_DRAWER_MOTION_DURATION_MS = 240;
/** 开合缓入缓出；等价 CSS `ease-in-out` */
export declare const SENS_DRAWER_MOTION_EASING = "cubic-bezier(0.42, 0, 0.58, 1)";
export interface SensDrawerProps {
    open: boolean;
    titleBar: ReactNode;
    children: ReactNode;
    size?: SensDrawerSize;
    /** 有蒙层（默认）/ 无蒙层；无蒙层时点面板外仍关闭 */
    mask?: boolean;
    onClose?: () => void;
    className?: string;
    style?: CSSProperties;
    bodyStyle?: CSSProperties;
}
/** 右侧抽屉容器：标题区由 SensTitleBar 承担（含右侧操作），面板尺寸和投影遵循抽屉组件规则。 */
export declare function SensDrawer({ open, titleBar, children, size, mask, onClose, className, style, bodyStyle, }: SensDrawerProps): import("react").JSX.Element | null;
