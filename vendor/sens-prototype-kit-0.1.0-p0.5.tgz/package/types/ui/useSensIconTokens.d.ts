/** 按 icons.md 角色直读 design token 图标色，禁止在组件里硬编码 hex 或读 antd runtime token */
export declare function useSensIconTokens(): {
    readonly default: string;
    readonly secondary: string;
    readonly disabled: string;
    readonly hover: string;
    readonly active: string;
    readonly onPrimary: string;
};
