import { type InputProps } from "antd";
import type { CSSProperties, ReactNode } from "react";
import "./input.css";
import "./input-preview.css";
export type SensInputWarningPlacement = "inside" | "outside";
export type SensInputReadOnlyVariant = "filled" | "plain";
/** 锁高 + 警告/只读 CSS 变量（paddingBlock=0 时由组件层补足 controlHeight） */
export declare function useSensInputHeightStyle(): CSSProperties;
export interface SensInputProps extends InputProps {
    /** 框内 / 框外警告；可编辑态自动 `status="error"`，只读态走浅红底/纯文本（无红框） */
    warningPlacement?: SensInputWarningPlacement;
    /** 框外警告文案；框内时兼作 SensTips 默认文案 */
    help?: ReactNode;
    /** 框内悬停图标时的 SensTips；缺省用 `help` */
    warningMessage?: ReactNode;
    /** 预览矩阵内部使用：静态样张不进入 live region */
    helpLive?: boolean;
    /** 只读有背景 `filled`（Figma 只读_背景）/ 只读无背景 `plain`（只读_字段）；设后自动 `readOnly` */
    readOnlyVariant?: SensInputReadOnlyVariant;
}
export declare function InsideErrorSuffix({ size, message, }: {
    size: InputProps["size"];
    message?: ReactNode;
}): import("react").JSX.Element;
export declare function InputHelpRow({ help, id, live }: {
    help: ReactNode;
    id?: string;
    live?: boolean;
}): import("react").JSX.Element;
/** 单行文本输入框：主题 token + 锁高（32 / 24）+ 框内/框外警告 + 只读态 */
export declare function SensInput({ className, style, size, status: statusProp, suffix, variant: variantProp, warningPlacement, help, warningMessage, helpLive, readOnly: readOnlyProp, readOnlyVariant, id: idProp, allowClear: allowClearProp, ["aria-describedby"]: ariaDescribedByProp, value, defaultValue, placeholder, showCount: showCountProp, count: countProp, maxLength, onChange, ...props }: SensInputProps): import("react").JSX.Element;
/** Figma 2214:13286 预览态：默认 / 悬停 / 聚焦 / 禁用 / 禁用悬停 / 只读有背景 / 只读无背景 */
export type InputPreviewState = "default" | "hover" | "focus" | "disabled" | "disabledHover" | "readOnlyFilled" | "readOnlyPlain";
export interface InputStatesPreviewProps {
    title?: ReactNode;
    filledValue?: string;
}
/**
 * Figma 2214:13286 变体×状态矩阵。
 * 12 行（3 警告 × 2 尺寸 × 2 内容）× 7 列状态；内容未输入/已输入成对双行，排版对齐按钮矩阵。
 */
export declare function InputStatesPreview({ title, filledValue }: InputStatesPreviewProps): import("react").JSX.Element;
