import type { SelectDropdownContentPhase } from "./useSelectDropdownSearch";
export interface SelectDropdownBodyProps {
    phase: SelectDropdownContentPhase;
    sourceCount: number;
    resultCount: number;
    onEmptyAction?: () => void;
}
export declare function SelectDropdownBody({ phase, sourceCount, resultCount, onEmptyAction, }: SelectDropdownBodyProps): import("react").JSX.Element;
