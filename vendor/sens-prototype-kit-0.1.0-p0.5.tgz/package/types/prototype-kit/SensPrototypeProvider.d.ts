import { type ReactNode } from 'react';
import type { FunctionalSkin } from '../design-system/functional-skin';
import type { NavigationTheme } from '../design-system/navigation-color';
export interface SensPrototypeProviderProps {
    children: ReactNode;
    locale?: 'zh-cn' | 'en';
    initialFunctionalSkin?: FunctionalSkin;
    initialNavigationTheme?: NavigationTheme;
}
/** Client-side prototype bootstrap; owns an isolated translation instance. */
export declare function SensPrototypeProvider({ children, locale, initialFunctionalSkin, initialNavigationTheme }: SensPrototypeProviderProps): import("react").JSX.Element;
