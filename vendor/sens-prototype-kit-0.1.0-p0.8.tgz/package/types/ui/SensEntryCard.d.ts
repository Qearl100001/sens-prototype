import { type ReactNode } from "react";
import { type SensCardProps } from "./SensCard";
import "./entry-card.css";
export type SensEntryCardSize = "large" | "small";
export interface SensEntryCardProps extends Omit<SensCardProps, "children" | "title"> {
    /** 入口卡片中的彩色业务图标或 SensIcon。 */
    icon: ReactNode;
    /** 入口名称；入口卡片标题不允许折行。 */
    title: ReactNode;
    /** 用于解释入口能力的辅助信息。 */
    description: ReactNode;
    /** 大号入口或小号入口。 */
    size?: SensEntryCardSize;
}
export declare function SensEntryCard({ size, icon, title, description, className, style, interactive, pressable, disabled, onKeyDown, tabIndex, role, ...cardProps }: SensEntryCardProps): import("react").JSX.Element;
