import type { HTMLAttributes, ReactNode } from "react";
import "./card.css";
export type SensCardVariant = "outline" | "filled";
export interface SensCardProps extends HTMLAttributes<HTMLDivElement> {
    /** 白底描边卡片或弱层级色块卡片。 */
    variant?: SensCardVariant;
    /** 启用 hover / pressed 的交互样式；点击语义由宿主通过 onClick / role 提供。 */
    interactive?: boolean;
    /** 是否启用 interactive 卡片的 pressed / 激活投影；操作外露型卡片通常关闭。 */
    pressable?: boolean;
    /** 仅用于选择型卡片的激活视觉，不替代宿主的选择语义。 */
    selected?: boolean;
    /** 禁用卡片交互和内容层级。 */
    disabled?: boolean;
    /** 错误状态卡片。 */
    error?: boolean;
    children?: ReactNode;
}
export declare function SensCard({ variant, interactive, pressable, selected, disabled, error, className, style, onClick, children, ...rootProps }: SensCardProps): import("react").JSX.Element;
