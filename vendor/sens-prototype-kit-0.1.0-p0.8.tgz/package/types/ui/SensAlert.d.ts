import type { CSSProperties, ReactNode } from "react";
import { type AlertType } from "./feedbackShared";
export type { AlertType } from "./feedbackShared";
export { ALERT_TYPE_LABEL } from "./feedbackShared";
export type SensAlertProps = {
    type?: AlertType;
    description?: ReactNode;
    closable?: boolean;
    link?: ReactNode;
    onClose?: () => void;
    children?: ReactNode;
    className?: string;
    style?: CSSProperties;
};
/**
 * 警告 Alert：语义浅底 + 浅描边页内条。
 * type 四档（无 loading）；状态色不换肤。
 */
export declare function SensAlert({ type, description, closable, link, onClose, children, className, style, }: SensAlertProps): import("react").JSX.Element;
/** 预览矩阵：type × 基础 / +辅助 / +关闭 / +链接 */
export declare function AlertTypesPreview(): import("react").JSX.Element;
