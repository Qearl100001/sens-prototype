import { type InputNumberProps } from "antd";
import type { CSSProperties, ReactNode } from "react";
import "./input.css";
import { type SensInputReadOnlyVariant, type SensInputWarningPlacement } from "./SensInput";
import "./input-preview.css";
import "./inputnumber.css";
import "./inputnumber-preview.css";
/** 数字框专有 CSS 变量（字段色与 SensInput 同源） */
export declare function useSensInputNumberStyle(size?: InputNumberProps["size"]): CSSProperties;
export type SensInputNumberWarningPlacement = SensInputWarningPlacement;
export type SensInputNumberReadOnlyVariant = SensInputReadOnlyVariant;
export interface SensInputNumberProps extends InputNumberProps {
    warningPlacement?: SensInputNumberWarningPlacement;
    help?: ReactNode;
    warningMessage?: ReactNode;
    readOnlyVariant?: SensInputNumberReadOnlyVariant;
}
/** 数字输入框：锁高 + 步进器 token + 框内/框外警告 + 只读态 */
export declare function SensInputNumber({ className, style, size, status: statusProp, variant: variantProp, warningPlacement, help, warningMessage, readOnly: readOnlyProp, readOnlyVariant, value, defaultValue, placeholder, controls: controlsProp, ...props }: SensInputNumberProps): import("react").JSX.Element;
export type InputNumberPreviewState = "default" | "hover" | "click" | "active" | "disabled" | "disabledHover" | "readOnlyFilled" | "readOnlyPlain";
export interface InputNumberStatesPreviewProps {
    title?: ReactNode;
    filledValue?: number;
}
/** Figma 17465:62974：3 警告 × 8 状态 × 2 内容 = 48 格 */
export declare function InputNumberStatesPreview({ title, filledValue, }: InputNumberStatesPreviewProps): import("react").JSX.Element;
